
<!-- README.md is generated from README.Rmd. Please edit that file -->

# RprojOSR <img src="man/figures/logo.png" align="right" height="138" alt="" />

<!-- badges: start -->
[![R-CMD-check](https://github.com/sdyrting/RprojOSR/actions/workflows/R-CMD-check.yaml/badge.svg)](https://github.com/sdyrting/RprojOSR/actions/workflows/R-CMD-check.yaml)
<!-- badges: end -->

The goal of RprojOSR is to provide an R interface to the Osier library
of demographic functions.

## Installation

You can install RprojOSR from its binary package:

``` r
install.packages('./RprojOSR_1.0.0.zip')
```

## Example

Create an object using population, fertility, mortality, or migration
data.

``` r
library(RprojOSR)
library(tidyverse)
library(ggplot2)

#
# Create a fertility object
#

asfr <- aus_f_asfr_2011

fert_name <- 'Published'
osr.CreateObj(fert_name,'FERTILITY',
              c('Population','Date','BuildMethod'),
              list('AUS-P/AUS-F',20110630,'CONSTANT_FERT'),
              'FertilityRates',
              c('Age','Rate','Use'),
              matrix(ncol=3,byrow=FALSE,data=c(asfr$age,asfr$rate,asfr$use)))
#> [1] "Published:0"
```

Objects can be copied or modified.

``` r

#
# Copy an object
#

xfert_name <- 'Expanded'
osr.CloneObj(xfert_name,fert_name,'FERTILITY')
#> [1] "Expanded:0"

#
# Modify an object
#

osr.ModifyObj(,xfert_name,'FERTILITY',,'BuildMethod',,'HFC:70000')
#> [1] "Expanded:1"
```

There are functions for calculating demographic rates and measures.

``` r

#
# Calculate measures
#

# Age-specific fertility rate
tibble(Age=seq(0,60)) %>%
  cross_join(tibble(Data=c(fert_name,xfert_name))) %>%
  group_by(Data,Age) %>%
  mutate(ASFR=osr.FertRate(Data,Age)) %>%
  ggplot()+
  geom_line(aes(x=Age,y=ASFR,group=Data,colour=Data))
```

<img src="man/figures/README-asfr-1.png" width="100%" />

``` r


# Total fertility rate
osr.TotalFertRate(xfert_name)
#> [1] 1.9169

# Mean age at childbearing
osr.MeanAgeChild(xfert_name)
#> [1] 30.5433
```
