#
# PCurves
#

retval <- osr.CreateObj(
  Handle = "IDN-P_PCURVE_1971",
  ObjectType = "PCURVE",
  BodyProps = list("Population","Date","BuildMethod","Source","Comment"),
  BodyValues = list("IDN-P",19710924,"CONSTANT_DENSITY","Feeney1979","Indonesian persons by age, unadjusted"),
  .TableName. = "Numbers",
  .TableCols. = list("Age","Number","Use"),
  .TableValues. = matrix(ncol=3,byrow=TRUE,data=list(
    0,	2337,	1,
    1,	3873,	1,
    2,	3882,	1,
    3,	3952,	1,
    4,	4056,	1,
    5,	3685,	1,
    6,	3687,	1,
    7,	3683,	1,
    8,	3611,	1,
    9,	3175,	1,
    10,	3457,	1,
    11,	2379,	1,
    12,	3023,	1,
    13,	2375,	1,
    14,	2316,	1,
    15,	2586,	1,
    16,	2014,	1,
    17,	2123,	1,
    18,	2584,	1,
    19,	1475,	1,
    20,	3006,	1,
    21,	1299,	1,
    22,	1236,	1,
    23,	1052,	1,
    24,	992,	1,
    25,	3550,	1,
    26,	1334,	1,
    27,	1314,	1,
    28,	1337,	1,
    29,	942,	1,
    30,	3951,	1,
    31,	1128,	1,
    32,	1108,	1,
    33,	727,	1,
    34,	610,	1,
    35,	3919,	1,
    36,	1221,	1,
    37,	868,	1,
    38,	979,	1,
    39,	637,	1,
    40,	3409,	1,
    41,	887,	1,
    42,	687,	1,
    43,	533,	1,
    44,	313,	1,
    45,	2488,	1,
    46,	677,	1,
    47,	426,	1,
    48,	524,	1,
    49,	333,	1,
    50,	2259,	1,
    51,	551,	1,
    52,	363,	1,
    53,	290,	1,
    54,	226,	1,
    55,	1153,	1,
    56,	379,	1,
    57,	217,	1,
    58,	223,	1,
    59,	152,	1,
    60,	1500,	1,
    61,	319,	1,
    62,	175,	1,
    63,	143,	1,
    64,	89,	1,
    65,	670,	1,
    66,	149,	1,
    67,	96,	1,
    68,	97,	1,
    69,	69,	1,
    70,	696,	1,
    71,	170,	1,
    72,	60,	1,
    73,	38,	1,
    74,	23,	1,
    75,	745,	1,
    "NotStated",	15,	1))
)
cat(retval,"\n")

retval <- osr.CreateObj(
  Handle = "AUS-I-P_PCURVE_2011",
  ObjectType = "PCURVE",
  BodyProps = list("Population","Date","BuildMethod","Source","Comment"),
  BodyValues = list("AUS-I-P","20110630","CONSTANT_DENSITY","ABS",
    "Australia indigenous persons by age, unadjusted"),
  .TableName. = "Numbers",
  .TableCols. = list("Age","Number","Use"),
  .TableValues. = matrix(ncol=3,byrow=TRUE,data=list(
    0,	1384,	1,
    1,	1539,	1,
    2,	1518,	1,
    3,	1429,	1,
    4,	1543,	1,
    5,	1673,	1,
    6,	1610,	1,
    7,	1516,	1,
    8,	1551,	1,
    9,	1487,	1,
    10,	1642,	1,
    11,	1417,	1,
    12,	1410,	1,
    13,	1432,	1,
    14,	1368,	1,
    15,	1379,	1,
    16,	1499,	1,
    17,	1372,	1,
    18,	1305,	1,
    19,	1295,	1,
    20,	1494,	1,
    21,	1365,	1,
    22,	1329,	1,
    23,	1247,	1,
    24,	1266,	1,
    25,	1336,	1,
    26,	1264,	1,
    27,	1189,	1,
    28,	1197,	1,
    29,	1188,	1,
    30,	1265,	1,
    31,	994,	1,
    32,	984,	1,
    33,	917,	1,
    34,	877,	1,
    35,	1048,	1,
    36,	915,	1,
    37,	919,	1,
    38,	1016,	1,
    39,	949,	1,
    40,	1120,	1,
    41,	899,	1,
    42,	894,	1,
    43,	853,	1,
    44,	764,	1,
    45,	823,	1,
    46,	689,	1,
    47,	662,	1,
    48,	670,	1,
    49,	634,	1,
    50,	776,	1,
    51,	520,	1,
    52,	580,	1,
    53,	566,	1,
    54,	531,	1,
    55,	518,	1,
    56,	462,	1,
    57,	413,	1,
    58,	386,	1,
    59,	348,	1,
    60,	447,	1,
    61,	304,	1,
    62,	243,	1,
    63,	240,	1,
    64,	234,	1,
    65,	240,	1,
    66,	190,	1,
    67,	171,	1,
    68,	135,	1,
    69,	154,	1,
    70,	185,	1,
    71,	118,	1,
    72,	91,	1,
    73,	80,	1,
    74,	81,	1,
    75,	701,	1))
)
cat(retval,"\n")

retval <- osr.CreateObj(
  Handle = "PAS-M_PCURVE",
  ObjectType = "PCURVE",
  BodyProps = list("Population","Date","BuildMethod","Source","Comment"),
  BodyValues = list("PAS-M",20171206,"CONSTANT_DENSITY","AGESMTH1.xls","Test"),
  .TableName. = "Numbers",
  .TableCols. = list("Age","Number"),
  .TableValues. = matrix(ncol=2,byrow=TRUE,data=list(
    0,	642367,
    5,	515520,
    10,	357831,
    15,	275542,
    20,	268336,
    25,	278601,
    30,	242515,
    35,	198231,
    40,	165937,
    45,	122756,
    50,	96775,
    55,	59307,
    60,	63467,
    65,	32377,
    70,	29796,
    75,	16183,
    80,	34729))
)
cat(retval,"\n")

retval <- osr.CreateObj(
  Handle = "PAS-F_PCURVE",
  ObjectType = "PCURVE",
  BodyProps = list("Population","Date","BuildMethod","Source","Comment"),
  BodyValues = list("PAS-F",20171206,"CONSTANT_DENSITY","AGESMTH1.xls","Test"),
  .TableName. = "Numbers",
  .TableCols. = list("Age","Number"),
  .TableValues. = matrix(ncol=2,byrow=TRUE,data=list(
    0,	654258,
    5,	503070,
    10,	323460,
    15,	265534,
    20,	322576,
    25,	306329,
    30,	245883,
    35,	179182,
    40,	145572,
    45,	95590,
    50,	81715,
    55,	48412,
    60,	54572,
    65,	28581,
    70,	26733,
    75,	14778,
    80,	30300))
)
cat(retval,"\n")

retval <- osr.CreateObj(
  Handle = "KEN-M_PCURVE_1989",
  ObjectType = "PCURVE",
  BodyProps = list("Population","Date","BuildMethod","Source"),
  BodyValues = list("KEN-M",19890824,"CONSTANT_DENSITY","WAMAI AGNES WAMUYU Masters Thesis"),
  .TableName. = "Numbers",
  .TableCols. = list("Age","Number"),
  .TableValues. = matrix(ncol=2,byrow=TRUE,data=list(
    0,	406759,
    1,	339262,
    2,	395265,
    3,	393903,
    4,	376027,
    5,	395278,
    6,	348366,
    7,	329529,
    8,	336942,
    9,	333532,
    10,	357423,
    11,	274993,
    12,	313189,
    13,	275699,
    14,	282741,
    15,	269559,
    16,	245055,
    17,	220135,
    18,	250956,
    19,	192278,
    20,	239272,
    21,	169420,
    22,	167076,
    23,	151644,
    24,	162182,
    25,	200743,
    26,	159744,
    27,	143250,
    28,	147107,
    29,	131630,
    30,	201279,
    31,	100133,
    32,	116720,
    33,	86433,
    34,	79208,
    35,	135636,
    36,	84660,
    37,	91408,
    38,	75528,
    39,	73717,
    40,	129170,
    41,	64184,
    42,	70614,
    43,	55644,
    44,	48321,
    45,	86422,
    46,	49908,
    47,	49152,
    48,	49364,
    49,	46280,
    50,	84481,
    51,	33636,
    52,	42113,
    53,	38450,
    54,	37226,
    55,	49409,
    56,	37079,
    57,	32365,
    58,	31137,
    59,	29027,
    60,	58470,
    61,	26105,
    62,	24531,
    63,	20682,
    64,	20708,
    65,	35346,
    66,	16074,
    67,	22813,
    68,	19748,
    69,	19708,
    70,	35807,
    71,	16807,
    72,	11189,
    73,	7842,
    74,	11320,
    75,	26913,
    76,	9218,
    77,	8526,
    78,	10910,
    79,	11032,
    80,	82210,
    "NotStated",	14740))
)
cat(retval,"\n")

retval <- osr.CreateObj(
  Handle = "KEN-F_PCURVE_1989",
  ObjectType = "PCURVE",
  BodyProps = list("Population","Date","BuildMethod","Source"),
  BodyValues = list("KEN-F",19890824,"CONSTANT_DENSITY","WAMAI AGNES WAMUYU Masters Thesis"),
  .TableName. = "Numbers",
  .TableCols. = list("Age","Number"),
  .TableValues. = matrix(ncol=2,byrow=TRUE,data=list(
    0,	400913,
    1,	332254,
    2,	394215,
    3,	390271,
    4,	371175,
    5,	385008,
    6,	346316,
    7,	324146,
    8,	339652,
    9,	330170,
    10,	349611,
    11,	278370,
    12,	305194,
    13,	274127,
    14,	278345,
    15,	269822,
    16,	250065,
    17,	217975,
    18,	258386,
    19,	204464,
    20,	287393,
    21,	186822,
    22,	193975,
    23,	168736,
    24,	176414,
    25,	226620,
    26,	169229,
    27,	150502,
    28,	171218,
    29,	129720,
    30,	223097,
    31,	88588,
    32,	107719,
    33,	80603,
    34,	75644,
    35,	138899,
    36,	83062,
    37,	85115,
    38,	80835,
    39,	70033,
    40,	145133,
    41,	56984,
    42,	60314,
    43,	52641,
    44,	49173,
    45,	92843,
    46,	54921,
    47,	46147,
    48,	52023,
    49,	47471,
    50,	99619,
    51,	33043,
    52,	36505,
    53,	33918,
    54,	37533,
    55,	47757,
    56,	33378,
    57,	30580,
    58,	33885,
    59,	35555,
    60,	74870,
    61,	28143,
    62,	23344,
    63,	20206,
    64,	21339,
    65,	37625,
    66,	14226,
    67,	18545,
    68,	21818,
    69,	24765,
    70,	42988,
    71,	17477,
    72,	12360,
    73,	7958,
    74,	10429,
    75,	23389,
    76,	8688,
    77,	7086,
    78,	9783,
    79,	11530,
    80,	94070,
    "NotStated",	10508))
)
cat(retval,"\n")

retval <- osr.CreateObj(
  Handle = "KEN-M_PCURVE_1999",
  ObjectType = "PCURVE",
  BodyProps = list("Population","Date","BuildMethod","Source"),
  BodyValues = list("KEN-M",19990825,"CONSTANT_DENSITY","WAMAI AGNES WAMUYU Masters Thesis"),
  .TableName. = "Numbers",
  .TableCols. = list("Age","Number"),
  .TableValues. = matrix(ncol=2,byrow=TRUE,data=list(
    0,	555876,
    1,	383031,
    2,	443325,
    3,	451109,
    4,	458595,
    5,	389416,
    6,	391682,
    7,	401992,
    8,	409378,
    9,	408112,
    10,	459800,
    11,	348009,
    12,	451935,
    13,	396613,
    14,	378623,
    15,	386684,
    16,	342868,
    17,	330280,
    18,	349169,
    19,	272983,
    20,	340365,
    21,	254758,
    22,	260746,
    23,	236190,
    24,	236470,
    25,	295668,
    26,	214409,
    27,	214514,
    28,	196012,
    29,	174306,
    30,	289616,
    31,	136811,
    32,	163916,
    33,	122638,
    34,	127711,
    35,	198702,
    36,	137267,
    37,	116444,
    38,	127760,
    39,	115090,
    40,	183275,
    41,	87980,
    42,	103341,
    43,	79361,
    44,	62545,
    45,	127990,
    46,	67413,
    47,	88377,
    48,	66244,
    49,	69817,
    50,	123091,
    51,	58507,
    52,	64286,
    53,	48835,
    54,	49920,
    55,	63513,
    56,	47652,
    57,	44028,
    58,	34557,
    59,	33941,
    60,	75974,
    61,	26504,
    62,	31558,
    63,	32760,
    64,	27717,
    65,	41508,
    66,	22957,
    67,	28548,
    68,	23314,
    69,	24642,
    70,	46801,
    71,	21747,
    72,	19963,
    73,	15340,
    74,	14750,
    75,	26100,
    76,	12176,
    77,	15621,
    78,	12669,
    79,	12600,
    80,	95300,
    "NotStated",	103487))
)
cat(retval,"\n")

retval <- osr.CreateObj(
  Handle = "KEN-F_PCURVE_1999",
  ObjectType = "PCURVE",
  BodyProps = list("Population","Date","BuildMethod","Source"),
  BodyValues = list("KEN-F",19990825,"CONSTANT_DENSITY","WAMAI AGNES WAMUYU Masters Thesis"),
  .TableName. = "Numbers",
  .TableCols. = list("Age","Number"),
  .TableValues. = matrix(ncol=2,byrow=TRUE,data=list(
    0,	540722,
    1,	373480,
    2,	436227,
    3,	446384,
    4,	446153,
    5,	376714,
    6,	388188,
    7,	390680,
    8,	407425,
    9,	399549,
    10,	450283,
    11,	362962,
    12,	433903,
    13,	389279,
    14,	367228,
    15,	381489,
    16,	351348,
    17,	333913,
    18,	361998,
    19,	292446,
    20,	404228,
    21,	277607,
    22,	298644,
    23,	265559,
    24,	258351,
    25,	332006,
    26,	224972,
    27,	213940,
    28,	223049,
    29,	170627,
    30,	323016,
    31,	121911,
    32,	163540,
    33,	116450,
    34,	120313,
    35,	213706,
    36,	138854,
    37,	118515,
    38,	144039,
    39,	108635,
    40,	205622,
    41,	79270,
    42,	94009,
    43,	76361,
    44,	61727,
    45,	135889,
    46,	66414,
    47,	82880,
    48,	68978,
    49,	64826,
    50,	136869,
    51,	53768,
    52,	55118,
    53,	43978,
    54,	50434,
    55,	66427,
    56,	52222,
    57,	42382,
    58,	36530,
    59,	38764,
    60,	95240,
    61,	28304,
    62,	29763,
    63,	30901,
    64,	30507,
    65,	48028,
    66,	21878,
    67,	27844,
    68,	29575,
    69,	33039,
    70,	61262,
    71,	23510,
    72,	20425,
    73,	15104,
    74,	15223,
    75,	27135,
    76,	12053,
    77,	12541,
    78,	13465,
    79,	16426,
    80,	121038,
    "NotStated",	86956))
)
cat(retval,"\n")

#
# BuildMethods - I
#


par(ask = TRUE)
cat("\nBuildMethods\n============\n\n")
BaseHandle <- "PAS-M_PCURVE"

BuildMethods <- list("CONSTANT_DENSITY","QUADRATIC_DENSITY","HYBRID_DENSITY","HYBRID_EXPONENTIAL",
                     "FEENEY","SPRAGUE")
NewHandles <- vector("character",length(BuildMethods))
for (i in 1:length(BuildMethods)) {
  NewHandles[i] <- osr.ModifyObj(BuildMethods[i],BaseHandle,"PCURVE",,"BuildMethod",,BuildMethods[i])
}
x <- 0:110
n <- numeric(length(x))
for (i in 1:length(x)) {
  n[i] <- osr.Number(BaseHandle,x[i])
}
plot(x,n,type="p",col=1,main="BuildMethods - I")
for (j in 1:length(NewHandles)) {
  for (i in 1:length(x)) {
    n[i] <- osr.Number(NewHandles[j],x[i])
  }
  lines(x,n,col=j,sub=NewHandles[j])
}
legend("topright",legend=NewHandles,col = c(1:length(NewHandles)),pch=15)

#
# BuildMethods - II
#


BuildMethods <- list("CONSTANT_DENSITY","WEIGHTED_AVERAGE","CARRIER_FARRAG",
                     "KARUP_KING_NEWTON","ARRIAGA","MOD_ARRIAGA")
NewHandles <- vector("character",length(BuildMethods))
for (i in 1:length(BuildMethods)) {
  NewHandles[i] <- osr.ModifyObj(BuildMethods[i],BaseHandle,"PCURVE",,"BuildMethod",,BuildMethods[i])
}
x <- 0:110
n <- numeric(length(x))
for (i in 1:length(x)) {
  n[i] <- osr.Number(BaseHandle,x[i])
}
plot(x,n,type="p",col=1,main="BuildMethods - II")
for (j in 1:length(NewHandles)) {
  for (i in 1:length(x)) {
    n[i] <- osr.Number(NewHandles[j],x[i])
  }
  lines(x,n,col=j,sub=NewHandles[j])
}
legend("topright",legend=NewHandles,col = c(1:length(NewHandles)),pch=15)


#
# BuildMethods - III
#

BuildMethods <- list('CONSTANT_DENSITY','UNITED_NATIONS','STRONG','PCLM:"MaxIts=20"')
NewHandles <- vector("character",length(BuildMethods))
for (i in 1:length(BuildMethods)) {
  NewHandles[i] <- osr.ModifyObj(BuildMethods[i],BaseHandle,"PCURVE",,"BuildMethod",,BuildMethods[i])
}
x <- 0:110
n <- numeric(length(x))
for (i in 1:length(x)) {
  n[i] <- osr.Number(BaseHandle,x[i])
}
plot(x,n,type="p",col=1,main="BuildMethods - III")
for (j in 1:length(NewHandles)) {
  for (i in 1:length(x)) {
    n[i] <- osr.Number(NewHandles[j],x[i])
  }
  lines(x,n,col=j,sub=NewHandles[j])
}
legend("topright",legend=NewHandles,col = c(1:length(NewHandles)),pch=15)

#
# Number
#

cat("\nNumber\n======\n\n")
BaseHandle <- "AUS-I-P_PCURVE_2011:0"
BuildMethod <- "UNITED_NATIONS"
PCurveHandle <- osr.ModifyObj(BuildMethod,BaseHandle,"PCURVE",,"BuildMethod",,BuildMethod)
Age <- 0:100
Ref <- numeric(length(Age))
Smooth <- numeric(length(Age))
for (i in 1:length(Age)) {
  Ref[i] <- osr.Number(BaseHandle,Age[i])
  Smooth[i] <- osr.Number(PCurveHandle,Age[i])
}
plot(Age,Ref,type="p",xlab="Age",ylab="Number")
lines(Age,Smooth,col=2)

#
# Total Number
#

cat("\nTotalNumber\n===========\n\n")
BaseHandle <- "AUS-I-P_PCURVE_2011:0"
BuildMethod <- "SPRAGUE"
PCurveHandle <- osr.ModifyObj(BuildMethod,BaseHandle,"PCURVE",,"BuildMethod",,BuildMethod)
cat(PCurveHandle,"\n")
cat("TotalNumber=",osr.TotalNumber(PCurveHandle),"\n")

#
# GetPCurveParams
#

cat("\nGetPCurveParams\n===============\n\n")

BaseHandle <- osr.CreateObj(
  Handle = "USA-P_DEATHS_CIR_5Y_2009",
  ObjectType = "PCURVE",
  BodyProps = list("Population","Date","BuildMethod"),
  BodyValues = list("USA-P","20091231",'PCLM:"MaxAge=120"'),
  .TableName. = "Numbers",
  .TableCols. = list("Age","Number"),
  .TableValues. = matrix(ncol=2,byrow=TRUE,data=list(
    0,	791.0332646,
    5,	136.0057193,
    10,	173.0072753,
    15,	428.017999,
    20,	921.0387316,
    25,	1506.063333,
    30,	2588.108835,
    35,	4871.204844,
    40,	9328.392278,
    45,	18002.75705,
    50,	28260.1884,
    55,	36894.55149,
    60,	46386.95067,
    65,	52210.19555,
    70,	63474.66924,
    75,	87319.67197,
    80,	124149.2207,
    85,	307300.9226,
    115,	0))
)

PCurveParams <- osr.GetPCurveParams(BaseHandle)
print(PCurveParams)

#
# MedianAge
#

cat("\nMedianAge\n===========\n\n")
BaseHandle <- "AUS-I-P_PCURVE_2011:0"
BuildMethod <- "SPRAGUE"
PCurveHandle <- osr.ModifyObj(BuildMethod,BaseHandle,"PCURVE",,"BuildMethod",,BuildMethod)
cat(PCurveHandle,"\n")
cat("MedianAge=",osr.MedianAge(PCurveHandle),"\n")
