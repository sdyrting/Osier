#
# AsfrFert
#

cat("\nAsfrFert\n========\n\n")
retval <- osr.CreateObj(
  Handle = "AUS-F_ASFR_2011",
  ObjectType =	"FERTILITY",
  BodyProps = list("Population","Date","BuildMethod"),
  BodyValues = list("AUS/AUS-F",20110630,"HYBRID_FERT"),
  .TableName. = "FertilityRates",
  .TableCols. = list("Age","Rate","Use"),
  .TableValues. = matrix(ncol=3,byrow=TRUE,data=list(
    15,	0.0029,	1,
    16,	0.0066,	1,
    17,	0.0137,	1,
    18,	0.0224,	1,
    19,	0.0336,	1,
    20,	0.0413,	1,
    21,	0.0448,	1,
    22,	0.0514,	1,
    23,	0.059,	1,
    24,	0.068,	1,
    25,	0.0797,	1,
    26,	0.0906,	1,
    27,	0.1045,	1,
    28,	0.1157,	1,
    29,	0.125,	1,
    30,	0.1271,	1,
    31,	0.1347,	1,
    32,	0.1288,	1,
    33,	0.1216,	1,
    34,	0.1116,	1,
    35,	0.1004,	1,
    36,	0.0866,	1,
    37,	0.0702,	1,
    38,	0.0561,	1,
    39,	0.0425,	1,
    40,	0.0297,	1,
    41,	0.0203,	1,
    42,	0.0128,	1,
    43,	0.0073,	1,
    44,	0.0038,	1,
    45,	0.002,	1,
    46,	0.001,	1,
    47,	0.0005,	1,
    48,	0.0002,	1,
    49,	0.0005,	1))
)
cat(retval,"\n")

retval <- osr.CreateObj(
  Handle = "AUS-F_ASFR_5Y_2011",
  ObjectType = "FERTILITY",
  BodyProps = list("Population","Date","BuildMethod"),
  BodyValues = list("AUS/AUS-F",20110630,"CONSTANT_FERT"),
  .TableName. = "FertilityRates",
  .TableCols. = list("Age","Rate","Use"),
  .TableValues. = matrix(ncol = 3, byrow = TRUE, data = list(
    15,	0.01584,	1,
    20,	0.0529,	1,
    25,	0.1031,	1,
    30,	0.12476,	1,
    35,	0.07116,	1,
    40,	0.01478,	1,
    45,	0.00084,	1,
    50,	0,	0,
    55,	0,	0))
)
cat(retval,"\n")

retval <- osr.CreateObj(
  Handle = "SWE-F_ASFR_1996",
  ObjectType = "FERTILITY",
  BodyProps = list("Population","Date","BuildMethod"),
  BodyValues = list("SWE-P/SWE-F",19960630,"CONSTANT_FERT"),
  .TableName. = "FertilityRates",
  .TableCols. = list("Age","Rate","Use"),
  .TableValues. = matrix(ncol = 3, byrow = TRUE, data = list(
    0,	0.000000,	1,
    13,	0.000020,	1,
    14,	0.000080,	1,
    15,	0.000570,	1,
    16,	0.002100,	1,
    17,	0.005380,	1,
    18,	0.009970,	1,
    19,	0.020430,	1,
    20,	0.032620,	1,
    21,	0.044540,	1,
    22,	0.056550,	1,
    23,	0.071440,	1,
    24,	0.084110,	1,
    25,	0.102860,	1,
    26,	0.113140,	1,
    27,	0.119240,	1,
    28,	0.120860,	1,
    29,	0.120030,	1,
    30,	0.114810,	1,
    31,	0.105140,	1,
    32,	0.093150,	1,
    33,	0.081710,	1,
    34,	0.069440,	1,
    35,	0.058250,	1,
    36,	0.049510,	1,
    37,	0.037760,	1,
    38,	0.028690,	1,
    39,	0.021220,	1,
    40,	0.014700,	1,
    41,	0.009330,	1,
    42,	0.006250,	1,
    43,	0.003250,	1,
    44,	0.001770,	1,
    45,	0.000880,	1,
    46,	0.000340,	1,
    47,	0.000140,	1,
    48,	0.000030,	1,
    49,	0.000000,	1,
    50,	0.000000,	1,
    51,	0.000020,	1,
    52,	0.000000,	1,
    53,	0.000000,	1,
    54,	0.000000,	1,
    55,	0.000000,	1,
    100,	0.000000,	0))
)
cat(retval,"\n")

retval <- osr.CreateObj(
  Handle = "ITA-F_ASFR_1996",
  ObjectType = "FERTILITY",
  BodyProps = list("Population","Date","BuildMethod"),
  BodyValues = list("ITA-P/ITA-F",19960630,"CONSTANT_FERT"),
  .TableName. = "FertilityRates",
  .TableCols. = list("Age","Rate","Use"),
  .TableValues. = matrix(ncol = 3, byrow = TRUE, data = list(
    0,	0.000000,	1,
    13,	0.000000,	1,
    14,	0.000010,	1,
    15,	0.000130,	1,
    16,	0.003100,	1,
    17,	0.005830,	1,
    18,	0.009460,	1,
    19,	0.015100,	1,
    20,	0.020170,	1,
    21,	0.026150,	1,
    22,	0.032510,	1,
    23,	0.040070,	1,
    24,	0.048470,	1,
    25,	0.056250,	1,
    26,	0.066900,	1,
    27,	0.078810,	1,
    28,	0.086350,	1,
    29,	0.091750,	1,
    30,	0.094380,	1,
    31,	0.092760,	1,
    32,	0.089070,	1,
    33,	0.081580,	1,
    34,	0.070900,	1,
    35,	0.060900,	1,
    36,	0.051850,	1,
    37,	0.039730,	1,
    38,	0.030820,	1,
    39,	0.022480,	1,
    40,	0.016280,	1,
    41,	0.010900,	1,
    42,	0.006710,	1,
    43,	0.003720,	1,
    44,	0.001740,	1,
    45,	0.000650,	1,
    46,	0.000360,	1,
    47,	0.000150,	1,
    48,	0.000080,	1,
    49,	0.000090,	1,
    50,	0.000030,	1,
    51,	0.000020,	1,
    52,	0.000010,	1,
    53,	0.000000,	1,
    54,	0.000000,	1,
    55,	0.000000,	1,
    100,	0.000000,	0))
)
cat(retval,"\n")

retval <- osr.CreateObj(
  Handle = "DNK-F_ASFR_1965",
  ObjectType = "FERTILITY",
  BodyProps = list("Population","Date","BuildMethod"),
  BodyValues = list("DNK-P/DNK-F",19650630,"CONSTANT_FERT"),
  .TableName. = "FertilityRates",
  .TableCols. = list("Age","Rate","Use"),
  .TableValues. = matrix(ncol = 3, byrow = TRUE, data = list(
    0,	0.001950,	1,
    16,	0.013250,	1,
    17,	0.036600,	1,
    18,	0.071640,	1,
    19,	0.110520,	1,
    20,	0.145570,	1,
    21,	0.171120,	1,
    22,	0.183530,	1,
    23,	0.189550,	1,
    24,	0.191500,	1,
    25,	0.189570,	1,
    26,	0.178140,	1,
    27,	0.163980,	1,
    28,	0.149260,	1,
    29,	0.132670,	1,
    30,	0.115350,	1,
    31,	0.098350,	1,
    32,	0.085300,	1,
    33,	0.073620,	1,
    34,	0.063550,	1,
    35,	0.054750,	1,
    36,	0.046450,	1,
    37,	0.038440,	1,
    38,	0.030240,	1,
    39,	0.023190,	1,
    40,	0.017310,	1,
    41,	0.012450,	1,
    42,	0.008380,	1,
    43,	0.005040,	1,
    44,	0.002970,	1,
    45,	0.001790,	1,
    46,	0.001120,	1,
    47,	0.000440,	1,
    48,	0.000070,	1,
    49,	0.000070,	1,
    148,	0.000000,	0))
)
cat(retval,"\n")

retval <- osr.CreateObj(
  Handle = "DNK-F_ASFR_1962",
  ObjectType = "FERTILITY",
  BodyProps = list("Population","Date","BuildMethod"),
  BodyValues = list("DNK-P/DNK-F",19620630,"CONSTANT_FERT"),
  .TableName. = "FertilityRates",
  .TableCols. = list("Age","Rate","Use"),
  .TableValues. = matrix(ncol = 3, byrow = TRUE, data = list(  
    0,	0.001360,	1,
    16,	0.011280,	1,
    17,	0.034760,	1,
    18,	0.069620,	1,
    19,	0.107410,	1,
    20,	0.138990,	1,
    21,	0.163920,	1,
    22,	0.179560,	1,
    23,	0.188690,	1,
    24,	0.191770,	1,
    25,	0.186750,	1,
    26,	0.174180,	1,
    27,	0.157040,	1,
    28,	0.141130,	1,
    29,	0.125010,	1,
    30,	0.112110,	1,
    31,	0.099270,	1,
    32,	0.086320,	1,
    33,	0.074180,	1,
    34,	0.063460,	1,
    35,	0.053180,	1,
    36,	0.044640,	1,
    37,	0.037520,	1,
    38,	0.030730,	1,
    39,	0.024070,	1,
    40,	0.018730,	1,
    41,	0.013770,	1,
    42,	0.009210,	1,
    43,	0.006190,	1,
    44,	0.003640,	1,
    45,	0.001860,	1,
    46,	0.000880,	1,
    47,	0.000370,	1,
    48,	0.000130,	1,
    49,	0.000060,	1,
    148,	0.000000,	0))
)
cat(retval,"\n")

#
# PCurves
#

cat("\nPCurves\n=======\n\n")
retval <- osr.CreateObj(
  Handle = "AUS-F_PCURVE_5Y_2011",
  ObjectType = "PCURVE",
  BodyProps = list("Population","Date","BuildMethod","Unspecified","Source","Reference"),
  BodyValues = list("AUS-F",20110630,"HYBRID_EXPONENTIAL",0,"Austalian Bureau of Statistics",
                   "3105.0.65.001 Australian Historical Population Statistics, 2014"),
  .TableName. = "Numbers",
  .TableCols. = list("Age","Number","Use"),
  .TableValues. = matrix(ncol = 3, byrow = TRUE, data = list(
    0,	709587,	1,
    5,	675429,	1,
    10,	676322,	1,
    15,	706860,	1,
    20,	788193,	1,
    25,	817086,	1,
    30,	766950,	1,
    35,	791706,	1,
    40,	800496,	1,
    45,	777690,	1,
    50,	754436,	1,
    55,	673924,	1,
    60,	614802,	1,
    65,	480007,	1,
    70,	370375,	1,
    75,	299930,	1,
    80,	253460,	1,
    85,	264537,	1))
)
cat(retval,"\n")

#
# Standard
#

cat("\nStandard\n========\n\n")
retval <- osr.CreateObj(
  Handle = "Booth1984",
  ObjectType = "FERTILITY",
  BodyProps = list("Population","Date","BuildMethod","Source","Comment"),
  BodyValues = list("XYZ-P/XYZ-F",19841130,"HYBRID_FERT","Booth1984",
                    "Booth's standard for the Brass relational model"),
  .TableName. = "FertilityRates",
  .TableCols. = list("Age","Rate","Use"),
  .TableValues. = matrix(ncol = 3, byrow = TRUE, data = list(
    10,	2.932716E-11,	1,
    11,	3.445567E-07,	1,
    12,	2.155602E-05,	1,
    13,	3.323120E-04,	1,
    14,	2.415960E-03,	1,
    15,	8.910686E-03,	1,
    16,	1.874469E-02,	1,
    17,	2.783667E-02,	1,
    18,	3.602250E-02,	1,
    19,	4.155101E-02,	1,
    20,	4.603433E-02,	1,
    21,	4.806300E-02,	1,
    22,	4.904060E-02,	1,
    23,	4.931619E-02,	1,
    24,	4.902099E-02,	1,
    25,	4.865447E-02,	1,
    26,	4.774257E-02,	1,
    27,	4.642460E-02,	1,
    28,	4.503541E-02,	1,
    29,	4.343742E-02,	1,
    30,	4.155398E-02,	1,
    31,	3.952269E-02,	1,
    32,	3.754254E-02,	1,
    33,	3.552287E-02,	1,
    34,	3.343319E-02,	1,
    35,	3.133221E-02,	1,
    36,	2.911991E-02,	1,
    37,	2.690765E-02,	1,
    38,	2.461907E-02,	1,
    39,	2.203105E-02,	1,
    40,	1.906372E-02,	1,
    41,	1.554181E-02,	1,
    42,	1.218559E-02,	1,
    43,	8.925422E-03,	1,
    44,	5.975803E-03,	1,
    45,	3.669347E-03,	1,
    46,	2.270664E-03,	1,
    47,	1.327485E-03,	1,
    48,	6.742912E-04,	1,
    49,	1.753936E-04,	1,
    50,	0.000000E+00,	-1))
)
cat(retval,"\n")

#
# ParamFert
#

cat("\nParamFert\n=========\n\n")
retval <- osr.CreateObj(
  Handle = "BrassParamFert",
  ObjectType = "FERTILITY",
  BodyProps = list("Population","Date","BuildMethod"),
  BodyValues = list("XYZ-P/XYZ-F",20190207,"BRASS"),
  .TableName. = "Parameters",
  .TableCols. = list("Alpha","Beta","TFR","Standard"),
  .TableValues. = matrix(ncol=4,byrow = TRUE, data=list(
    0,	0.9,	5,	"Booth1984"))
)
cat(retval,"\n")

#
# BuildMethods - I
#

par(ask = TRUE)

cat("\nBuildMethods\n============\n\n")
BaseHandle <- "AUS-F_ASFR_5Y_2011"
RefHandle <- "AUS-F_ASFR_2011"
BuildMethods <- list('CONSTANT_FERT','HFD:"YMIN=-8"','HYBRID_FERT','COALE_TRUSSELL','GAMMA')
NewHandles <- vector("character",length(BuildMethods))
for (i in 1:length(BuildMethods)) {
  NewHandles[i] <- osr.ModifyObj(BuildMethods[i],BaseHandle,"FERTILITY",,"BuildMethod",,BuildMethods[i])
}
x <- 12:54
f <- numeric(length(x))
for (i in 1:length(x)) {
  f[i] <- osr.FertRate(RefHandle,x[i])
}
plot(x,f,type="l",col=1,main="BuildMethods - I")
for (j in 1:length(NewHandles)) {
  for (i in 1:length(x)) {
    f[i] <- osr.FertRate(NewHandles[j],x[i])
  }
  lines(x,f,col=j+1,sub=NewHandles[j])
}
legend("topright",legend=c("Ref",NewHandles),col = c(1:(length(NewHandles)+1)),pch=15)

#
# BuildMethods - II
#

BuildMethods <- list("HADWIGER","QUADRATIC_SPLINE","CALIBRATED_SPLINE:100000","BEERS","HFC:700000")
NewHandles <- vector("character",length(BuildMethods))
for (i in 1:length(BuildMethods)) {
  NewHandles[i] <- osr.ModifyObj(BuildMethods[i],BaseHandle,"FERTILITY",,"BuildMethod",,BuildMethods[i])
}
x <- 12:54
f <- numeric(length(x))
for (i in 1:length(x)) {
  f[i] <- osr.FertRate(RefHandle,x[i])
}
plot(x,f,type="l",col=1,main="BuildMethods - II")
for (j in 1:length(NewHandles)) {
  for (i in 1:length(x)) {
    f[i] <- osr.FertRate(NewHandles[j],x[i])
  }
  lines(x,f,col=j+1,sub=NewHandles[j])
}
legend("topright",legend=c("Ref",NewHandles),col = c(1:(length(NewHandles)+1)),pch=15)

#
# BuildMethods - III
#

BuildMethods <- list('BRASS:"Booth1984","FitType=FR"',"BETA",
                     'PERISTERA_KOSTAKI:"ErrType=POISSON","Pcurve=AUS-F_PCURVE_5Y_2011"',	
                     'HADWIGER_MIX:"ErrType=ABS","Pcurve=AUS-F_PCURVE_5Y_2011","B1=5","FitB1=0"',
                     'WEIBULL_MIX:"ErrType=POISSON","Pcurve=AUS-F_PCURVE_5Y_2011"')
NewHandles <- vector("character",length(BuildMethods))
for (i in 1:length(BuildMethods)) {
  NewHandles[i] <- osr.ModifyObj(BuildMethods[i],BaseHandle,"FERTILITY",,"BuildMethod",,BuildMethods[i])
}
x <- 12:54
f <- numeric(length(x))
for (i in 1:length(x)) {
  f[i] <- osr.FertRate(RefHandle,x[i])
}
plot(x,f,type="l",col=1,main="BuildMethods - III")
for (j in 1:length(NewHandles)) {
  for (i in 1:length(x)) {
    f[i] <- osr.FertRate(NewHandles[j],x[i])
  }
  lines(x,f,col=j+1,sub=NewHandles[j])
}
legend("topright",legend=c("Ref",NewHandles),col = c(1:(length(NewHandles)+1)),pch=15)

#
# BuildMethods - IV
#

BuildMethods <- list('PTOPALS:"AUS-F_PCURVE_5Y_2011","Booth1984"',
                     'PERISTERA_KOSTAKI6:"ErrType=POISSON","Pcurve=AUS-F_PCURVE_5Y_2011"')
NewHandles <- vector("character",length(BuildMethods))
for (i in 1:length(BuildMethods)) {
  NewHandles[i] <- osr.ModifyObj(BuildMethods[i],BaseHandle,"FERTILITY",,"BuildMethod",,BuildMethods[i])
}
x <- 12:54
f <- numeric(length(x))
for (i in 1:length(x)) {
  f[i] <- osr.FertRate(RefHandle,x[i])
}
plot(x,f,type="l",col=1,main="BuildMethods - IV")
for (j in 1:length(NewHandles)) {
  for (i in 1:length(x)) {
    f[i] <- osr.FertRate(NewHandles[j],x[i])
  }
  lines(x,f,col=j+1,sub=NewHandles[j])
}
legend("topright",legend=c("Ref",NewHandles),col = c(1:(length(NewHandles)+1)),pch=15)

#
# Compare
#

FertHandle1 <- "AUS-F_ASFR_2011"
FertHandle2 <- "HFC"
FertHandle3 <- "BRASS"

#
# FertRate
#

cat("\nFertRate\n========\n\n")
Age <- 12:60
y1 <- numeric(length(Age))
y2 <- numeric(length(Age))
y3 <- numeric(length(Age))
for (i in 1:length(Age)) {
  y1[i] <- osr.FertRate(FertHandle1,Age[i])
  y2[i] <- osr.FertRate(FertHandle2,Age[i])
  y3[i] <- osr.FertRate(FertHandle3,Age[i])
}
plot(Age,y1,type="l",col="black",main="FertRate")
lines(Age,y2,col="blue")
lines(Age,y3,col="red")

#
# TotalFertRate
#

cat("\nTotalFertRate\n=============\n\n")
cat(FertHandle1,":",osr.TotalFertRate(FertHandle1),"\n")
cat(FertHandle2,":",osr.TotalFertRate(FertHandle2),"\n")
cat(FertHandle3,":",osr.TotalFertRate(FertHandle3),"\n")

#
# NetReproRate
#

cat("\nNetReproRate\n============\n\n")
MortHandle <- osr.CreateObj(
  Handle = "AUS-F_ASDR_2011",
  ObjectType = "MORTALITY",
  BodyProps = list("Population","Date","BuildMethod"),
  BodyValues = list("AUS-F",20110630,"HYBRID_FORCE"),
  .TableName. = "DeathRates",
  .TableCols. = list("Age","Rate","Use"),
  .TableValues. = matrix(ncol = 3, byrow = TRUE, data = list(
    0,	0.0035,	1,
    1,	0.0002,	1,
    5,	0.0001,	1,
    10,	0.0001,	1,
    15,	0.0002,	1,
    20,	0.0003,	1,
    25,	0.0003,	1,
    30,	0.0004,	1,
    35,	0.0006,	1,
    40,	0.0009,	1,
    45,	0.0014,	1,
    50,	0.0022,	1,
    55,	0.0031,	1,
    60,	0.0048,	1,
    65,	0.0079,	1,
    70,	0.0138,	1,
    75,	0.0234,	1,
    80,	0.0458,	1,
    85,	0.13,	1))
)

FertHandle <- "AUS-F_ASFR_2011"
SexRatio <- 1.05
Epsilon <- 1.0E-7
NRR <- osr.NetReproRate(FertHandle,MortHandle,SexRatio,Epsilon)
cat("Net Repro Rate = ",NRR,"\n")

#
# Births
#

cat("\nBirths\n======\n\n")
PCurveHandle <- osr.CreateObj(
  Handle = "AUS-F_5Y_2011",
  ObjectType = "PCURVE",
  BodyProps = list("Population",
                   "Date",
                   "BuildMethod",
                   "Unspecified",
                   "Source",
                   "Reference"),
  BodyValues = list("AUS-F",
                    20110630,
                    "HYBRID_EXPONENTIAL",
                    0,
                    "Austalian Bureau of Statistics",
                    "3105.0.65.001 Australian Historical Population Statistics, 2014"),
  .TableName. = "Numbers",
  .TableCols. = list("Age","Number","Use"),
  .TableValues. = matrix(ncol = 3, byrow = TRUE, data = list(
    0,	709587,	1,
    5,	675429,	1,
    10,	676322,	1,
    15,	706860,	1,
    20,	788193,	1,
    25,	817086,	1,
    30,	766950,	1,
    35,	791706,	1,
    40,	800496,	1,
    45,	777690,	1,
    50,	754436,	1,
    55,	673924,	1,
    60,	614802,	1,
    65,	480007,	1,
    70,	370375,	1,
    75,	299930,	1,
    80,	253460,	1,
    85,	264537,	1))
)
Epsilon <- 1.0E-8
Births <- osr.Births(FertHandle,PCurveHandle,Epsilon)
cat("Births = ",Births,"\n")

#
# GetFertParams
#

cat("\nGetFertParams\n=============\n\n")
Handle <- "WEIBULL_MIX:0"
FertParams <- osr.GetFertParams(Handle)
print(FertParams)
