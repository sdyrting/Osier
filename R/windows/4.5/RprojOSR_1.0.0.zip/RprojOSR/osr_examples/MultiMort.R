#
# MultiMort
#

cat("\nMultiMort\n=========\n\n")
DRMultiMort <- osr.CreateObj(
  Handle = "USD-W-M_ASDR_1970",
  ObjectType = "MORTALITY",
  BodyProps = list("Population","Date","BuildMethod","MultiDecBuildMethod"),
  BodyValues = list("USA-W-M",19700630,'CALIBRATED_SPLINE:"P=1000000"',"HYBRID_RATIO"),
  .TableName. = "DeathRates",
  .TableCols. = list("Age","Rate"),
  .TableValues. = matrix(ncol=2,byrow=TRUE,data=list(
    0,	0.02113239,
    1,	0.000836017,
    5,	0.000474801,
    10,	0.000485071,
    15,	0.001471427,
    20,	0.001989967,
    25,	0.001691855,
    30,	0.001853781,
    35,	0.002604102,
    40,	0.004200407,
    45,	0.006845684,
    50,	0.010986321,
    55,	0.017746092,
    60,	0.027083745,
    65,	0.040461201,
    70,	0.058280413,
    75,	0.086934172,
    80,	0.126068196,
    85,	0.185517407)),
  .TableName2. = "DeathRatios",
  .TableCols2. = list("Age","CAN","CIR","ACC","OTH"),
  .TableValues2. = matrix(ncol=5,byrow=TRUE,data=list(
    0,	65,	267,	935,	30458,
    1,	501,	163,	2119,	2127,
    5,	708,	134,	2119,	1138,
    10,	526,	163,	2708,	985,
    15,	742,	319,	9628,	1511,
    20,	867,	443,	10834,	1668,
    25,	800,	595,	7051,	1451,
    30,	941,	1202,	5246,	1741,
    35,	1608,	3104,	5059,	2688,
    40,	3392,	7848,	5608,	4971,
    45,	6463,	15817,	5955,	7757,
    50,	10893,	25843,	5782,	10574,
    55,	17133,	38853,	5791,	14725,
    60,	22505,	52365,	5145,	18766,
    65,	24691,	63340,	4404,	21179,
    70,	24317,	72177,	3890,	22445,
    75,	21468,	77556,	3495,	22460,
    80,	14260,	67265,	2746,	17285,
    85,	8630,	63998,	2469,	15242))
)
cat(DRMultiMort,"\n")

SFMultiMort <- osr.CreateObj(
  Handle = "USD-W-M_SF_1970",
  ObjectType = "MORTALITY",
  BodyProps = list("Population","Date","BuildMethod","MultiDecBuildMethod"),
  BodyValues = list("USA-W-M",19700630,"HELIGMAN_POLLARD8","HYBRID_RATIO"),
  .TableName. = "SurvivalFractions",
  .TableCols. = list("Age","SurvivalFraction"),
  .TableValues. = matrix(ncol=2,byrow=TRUE,data=list(
    0,	1,
    1,	0.979156079,
    5,	0.975888266,
    10,	0.973574439,
    15,	0.971215554,
    20,	0.964094161,
    25,	0.954548712,
    30,	0.946508207,
    35,	0.937773994,
    40,	0.925636956,
    45,	0.906382596,
    50,	0.875841109,
    55,	0.828923886,
    60,	0.75831596,
    65,	0.661850891,
    70,	0.539918456,
    75,	0.402299856,
    80,	0.258883527,
    85,	0.136293612)),
  .TableName2. = "DeathRatios",
  .TableCols2. = list("Age","CAN","CIR","ACC","OTH"),
  .TableValues2. = matrix(ncol=5,byrow=TRUE,data=list(
    0,	65,	267,	935,	30458,
    1,	501,	163,	2119,	2127,
    5,	708,	134,	2119,	1138,
    10,	526,	163,	2708,	985,
    15,	742,	319,	9628,	1511,
    20,	867,	443,	10834,	1668,
    25,	800,	595,	7051,	1451,
    30,	941,	1202,	5246,	1741,
    35,	1608,	3104,	5059,	2688,
    40,	3392,	7848,	5608,	4971,
    45,	6463,	15817,	5955,	7757,
    50,	10893,	25843,	5782,	10574,
    55,	17133,	38853,	5791,	14725,
    60,	22505,	52365,	5145,	18766,
    65,	24691,	63340,	4404,	21179,
    70,	24317,	72177,	3890,	22445,
    75,	21468,	77556,	3495,	22460,
    80,	14260,	67265,	2746,	17285,
    85,	8630,	63998,	2469,	15242))
)
cat(SFMultiMort,"\n")

MultiMort <- DRMultiMort

#
# DeathRate
#
par(ask = TRUE)

cat("\nDeathRate\n=========\n\n")

Age <- 0:110
Cause <- c("CAN","CIR","ACC","OTH")
CSR <- matrix(0,length(Age),length(Cause))
Total <- numeric(length(Age))
for (i in 1:length(Age)) {
  Total[i] <- osr.DeathRate(MultiMort,Age[i])
  for (j in 1:length(Cause)) {
    CSR[i,j] <- osr.DeathRate(MultiMort,Age[i],,Cause[j])
  }
}
plot(Age,Total,type="l",xlab="Age",ylab="DeathRate",log="y",ylim=c(0.00001,1))
for (j in 1:length(Cause)) {
  lines(Age,CSR[,j],col=j+1)
}
legend("topleft",legend=c("Total",Cause),col = 1:(1+length(Cause)),pch=15)

#
# DeathProb
#

cat("\nDeathProb\n=========\n\n")
AgeInterval <- 5
for (i in 1:length(Age)) {
  Total[i] <- osr.DeathProb(MultiMort,Age[i],AgeInterval)
  for (j in 1:length(Cause)) {
    CSR[i,j] <- osr.DeathProb(MultiMort,Age[i],AgeInterval,Cause[j])
  }
}
plot(Age,Total,type="l",xlab="Age",ylab="DeathProb",log="y",ylim=c(0.00001,1))
for (j in 1:length(Cause)) {
  lines(Age,CSR[,j],col=j+1)
}
legend("topleft",legend=c("Total",Cause),col = 1:(1+length(Cause)),pch=15)

#
# Deaths
#

cat("\nDeaths\n======\n\n")
AgeInterval <- 5
for (i in 1:length(Age)) {
  Total[i] <- osr.Deaths(MultiMort,Age[i],AgeInterval)
  for (j in 1:length(Cause)) {
    CSR[i,j] <- osr.Deaths(MultiMort,Age[i],AgeInterval,Cause[j])
  }
}
plot(Age,Total,type="l",xlab="Age",ylab="Deaths")
for (j in 1:length(Cause)) {
  lines(Age,CSR[,j],col=j+1)
}
legend("topleft",legend=c("Total",Cause),col = 1:(1+length(Cause)),pch=15)

#
# SurvFrac
#

cat("\nSurvFrac\n========\n\n")
for (i in 1:length(Age)) {
  Total[i] <- osr.SurvFrac(MultiMort,Age[i])
  for (j in 1:length(Cause)) {
    CSR[i,j] <- osr.SurvFrac(MultiMort,Age[i],Cause[j])
  }
}
plot(Age,Total,type="l",xlab="Age",ylab="SurvFrac")
for (j in 1:length(Cause)) {
  lines(Age,CSR[,j],col=j+1)
}
legend("topleft",legend=c("Total",Cause),col = 1:(1+length(Cause)),pch=15)

#
# DeathDist
#

cat("\nDeathDist\n=========\n\n")
for (i in 1:length(Age)) {
  Total[i] <- osr.DeathDist(MultiMort,Age[i])
  for (j in 1:length(Cause)) {
    CSR[i,j] <- osr.DeathDist(MultiMort,Age[i],Cause[j])
  }
}
plot(Age,Total,type="l",xlab="Age",ylab="DeathDist")
for (j in 1:length(Cause)) {
  lines(Age,CSR[,j],col=j+1)
}
legend("topleft",legend=c("Total",Cause),col = 1:(1+length(Cause)),pch=15)

#
# DyingProb
#

cat("\nDyingProb\n==========\n\n")
for (i in 1:length(Age)) {
  for (j in 1:length(Cause)) {
    CSR[i,j] <- osr.DyingProb(MultiMort,Cause[j],Age[i])
  }
}
plot(Age,CSR[,1],type="l",xlab="Age",ylab="DyingProb",ylim=c(0.0,0.8))
for (j in 2:length(Cause)) {
  lines(Age,CSR[,j],col=j+1)
}
legend("topleft",legend=Cause,col = 1:length(Cause),pch=15)

#
# SDSurvFrac
#

cat("\nSDSurvFrac\n==========\n\n")
for (i in 1:length(Age)) {
  for (j in 1:length(Cause)) {
    CSR[i,j] <- osr.SDSurvFrac(MultiMort,Cause[j],Age[i])
  }
}
plot(Age,CSR[,1],type="l",xlab="Age",ylab="SDSurvFrac",ylim=c(0.0,1.0))
for (j in 2:length(Cause)) {
  lines(Age,CSR[,j],col=j+1)
}
legend("bottomleft",legend=Cause,col = 1:length(Cause),pch=15)


#
# SDYearsLived
#

cat("\nSDYearsLived\n============\n\n")
for (i in 1:length(Age)) {
  for (j in 1:length(Cause)) {
    CSR[i,j] <- osr.SDYearsLived(MultiMort,Cause[j],Age[i])
  }
}
plot(Age,CSR[,1],type="l",xlab="Age",ylab="SDYearsLived",ylim=c(0.0,1.0))
for (j in 2:length(Cause)) {
  lines(Age,CSR[,j],col=j+1)
}
legend("bottomleft",legend=Cause,col = 1:length(Cause),pch=15)

#
# SDYearsLivedAfter
#

cat("\nSDYearsLivedAfter\n=================\n\n")
for (i in 1:length(Age)) {
  for (j in 1:length(Cause)) {
    CSR[i,j] <- osr.SDYearsLivedAfter(MultiMort,Cause[j],Age[i])
  }
}
plot(Age,CSR[,1],type="l",xlab="Age",ylab="SDYearsLivedAfter",ylim=c(0,160))
for (j in 2:length(Cause)) {
  lines(Age,CSR[,j],col=j+1)
}
legend("bottomleft",legend=Cause,col = 1:length(Cause),pch=15)

#
# CreateScenarioMort
#

cat("\nCreateScenarioMort\n==================\n\n")
NoCANSc <- osr.CreateObj(
  Handle = "NoCAN",
  ObjectType = "RESULTS",
  BodyProps = list("Scenario","Cause"),
  BodyValues = list("MULTIDEC","~CAN")
)

NoCANMort <- osr.CreateScenarioMort(
  NewMortHandle = "NoCANMort",
  MortHandle = MultiMort,
  ScenarioHandle = NoCANSc)
cat(NoCANMort,"\n")

cat("LifeExp=",osr.LifeExp(NoCANMort),"\n")