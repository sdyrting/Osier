## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup, warning=FALSE, message=FALSE--------------------------------------
library(RprojOSR)
library(dplyr)
library(ggplot2)

#
# Abridged fertility rates
#

asfr <- aus_f_asfr_2011

head(asfr)

## -----------------------------------------------------------------------------

osr.CreateObj(
  Handle = "AUS-F_ASFR_5Y_2011",
  ObjectType = "FERTILITY",
  BodyProps = list("Population","Date","BuildMethod"),
  BodyValues = list("AUS/AUS-F",20110630,"CONSTANT_FERT"),
  .TableName. = "FertilityRates",
  .TableCols. = list("Age","Rate","Use"),
  .TableValues. = matrix(ncol = 3, byrow = FALSE, data = c(asfr$age,asfr$rate,asfr$use))
)


## -----------------------------------------------------------------------------

# 
# Exposed population
#

num <- aus_f_num_2011

osr.CreateObj(
  Handle = "AUS-F_PCURVE_5Y_2011",
  ObjectType = "PCURVE",
  BodyProps = list("Population","Date","BuildMethod"),
  BodyValues = list("AUS-F",20110630,"HYBRID_EXPONENTIAL"),
  .TableName. = "Numbers",
  .TableCols. = list("Age","Number","Use"),
  .TableValues. = matrix(ncol = 3, byrow = FALSE, data = c(num$age,num$number,num$use))
)


## -----------------------------------------------------------------------------

#
# Standard fertility object
#

std_asfr <- booth84_asfr

osr.CreateObj(
  Handle = "Booth1984",
  ObjectType = "FERTILITY",
  BodyProps = list("Population","Date","BuildMethod"),
  BodyValues = list("XYZ-P/XYZ-F",19841130,"HYBRID_FERT"),
  .TableName. = "FertilityRates",
  .TableCols. = list("Age","Rate","Use"),
  .TableValues. = matrix(ncol = 3, byrow = FALSE, data = c(std_asfr$age,std_asfr$rate,std_asfr$use))
)


## -----------------------------------------------------------------------------

BaseHandle <- "AUS-F_ASFR_5Y_2011"

fert_objs <- tibble(
  BuildMethod = c(
    # Polynomial buildmethods
    'CONSTANT_FERT',
    'HFD:"YMIN=-8"',
    'HYBRID_FERT',
    # Parametric buildmethods
    'WEIBULL_MIX:"ErrType=POISSON","Pcurve=AUS-F_PCURVE_5Y_2011"',
    'HADWIGER_MIX:"ErrType=POISSON","Pcurve=AUS-F_PCURVE_5Y_2011","B1=5","FitB1=0"',
                  'PERISTERA_KOSTAKI:"ErrType=POISSON","Pcurve=AUS-F_PCURVE_5Y_2011"',
    # Non-parametric, relational, and hybrid buildmethods
    'HFC:700000',
    'BRASS:"Booth1984","FitType=FR"',
    'PTOPALS:"AUS-F_PCURVE_5Y_2011","Booth1984","Degree=2"'
    ),
  Name = c('CONSTANT_FERT',
           'HFD',
           'HYBRID_FERT',
           'WEIBULL_MIX',
           'HADWIGER_MIX',
           'PERISTERA_KOSTAKI',
           'HFC',
           'BRASS',
           'PTOPALS')) %>%
  group_by(BuildMethod) %>%
  mutate(
    Handle=osr.ModifyObj(Name,BaseHandle,'FERTILITY',NULL,'BuildMethod',NULL,BuildMethod)
  )

## -----------------------------------------------------------------------------
AgeInterval <- 0.1

fert_ages <- tibble(
  Age=seq(12,54,AgeInterval)
)

asfr_data <- fert_objs %>%
  cross_join(fert_ages) %>%
  group_by(Handle,Age) %>%
  mutate(ASFR=osr.FertRate(Handle,Age,AgeInterval))

## ----fig.width=8--------------------------------------------------------------
interp_methods <- c('CONSTANT_FERT',
                  'HFD',
                  'HYBRID_FERT')

interp_asfr_plot <- asfr_data %>%
  filter(Name %in% interp_methods) %>%
  ggplot() +
  geom_line(aes(x=Age,y=ASFR,group=Name,colour=Name))+
  ggtitle('Interpolation Methods')

interp_asfr_plot

## ----fig.width=8--------------------------------------------------------------
param_methods <- c('WEIBULL_MIX',
                   'HADWIGER_MIX',
                  'PERISTERA_KOSTAKI')

param_asfr_plot <- asfr_data %>%
  filter(Name %in% param_methods) %>%
  ggplot() +
  geom_line(aes(x=Age,y=ASFR,group=Name,colour=Name))+
  ggtitle('Parametric Methods')

param_asfr_plot

## ----fig.width=8--------------------------------------------------------------
other_methods <- c('HFC',
                  'BRASS',
                  'PTOPALS')

other_asfr_plot <- asfr_data %>%
  filter(Name %in% other_methods) %>%
  ggplot() +
  geom_line(aes(x=Age,y=ASFR,group=Name,colour=Name))+
  ggtitle('Other Methods')

other_asfr_plot

