## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup, warning=FALSE, message=FALSE--------------------------------------
library(RprojOSR)
library(dplyr)
library(ggplot2)

#
# 1Y out-migration probabilities
#

asmp <- vic_p_asmp_2010_2011


## ----echo=FALSE, fig.width=8, fig.height=6------------------------------------

asmp %>% ggplot() +
  geom_point(aes(x=age,y=prob))+
  theme_classic()+
  ggtitle('Sample Probabilities')

## -----------------------------------------------------------------------------
osr.CreateObj(
  Handle = "VIC-P_ASMP_ST_2010_2011",
  ObjectType = "MIGRATION",
  BodyProps = list("Population","Date","BuildMethod"),
  BodyValues = list("XVIC-P/VIC-P",20100630,"CONSTANT_INTENSITY"),
  .TableName. = "MigrationProbabilities",
  .TableCols. = list("Age","Probability","Use"),
  .TableValues. = matrix(ncol=3,byrow=FALSE,data=c(asmp$age,asmp$prob,asmp$use))
  )

## -----------------------------------------------------------------------------
#
# Exposed populations
#

num <- vic_p_num_2010_2011

osr.CreateObj(
  Handle = "VIC-P_N_PCURVE_2010_2011",
  ObjectType = "PCURVE",
  BodyProps = list("Population","Date","BuildMethod"),
  BodyValues = list("VIC-P",20100630,"CONSTANT_DENSITY"),
  .TableName. = "Numbers",
  .TableCols. = list("Age","Number","Use"),
  .TableValues. = matrix(ncol=3,byrow=FALSE,data=c(num$age,num$number,num$use))
)


## -----------------------------------------------------------------------------

BaseHandle <- 'VIC-P_ASMP_ST_2010_2011'

omig_objs <- tibble(
  BuildMethod = c('CONSTANT_INTENSITY',
                  'ROGERS_CASTRO_WILSON:"A4=0","FitElderly=0"',
                  'PTOPALS:"VIC-P_N_PCURVE_2010_2011","ROGERS_CASTRO_WILSON","Degree=2"'),
  Name = c('CONSTANT_INTENSITY',
                  'ROGERS_CASTRO_WILSON',
                  'PTOPALS')) %>%
  group_by(BuildMethod) %>%
  mutate(
    Handle=osr.ModifyObj(Name,BaseHandle,'MIGRATION',NULL,'BuildMethod',NULL,BuildMethod)
  )

## ----fig.width=8,fig.height=6-------------------------------------------------

AgeInterval <- 1

omig_ages <- tibble(
  Age=seq(0,99,AgeInterval)
)

asmp_data <- omig_objs %>%
  cross_join(omig_ages) %>%
  group_by(Handle,Age) %>%
  mutate(ASMP=osr.MigrationProb(Handle,Age,AgeInterval))

asmp_plot <- asmp_data %>%
  filter(Name %in% c("ROGERS_CASTRO_WILSON","PTOPALS")) %>%
  ggplot() +
  geom_line(aes(x=Age,y=ASMP,group=Name,colour=Name))+
  geom_point(data=asmp_data %>% filter(Name == "CONSTANT_INTENSITY"),
             aes(x=Age,y=ASMP),alpha=0.7,colour='grey',fill='grey')+ 
  theme_classic()+
  ggtitle('Smoothed Probabilities')

asmp_plot

