## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup--------------------------------------------------------------------
library(RprojOSR)

#
# Create an object
#

osr.CreateObj(
  Handle = 'NT-I-F_PCURVE_2021',
  ObjectType = "PCURVE",
  BodyProps = list("Population","Date","BuildMethod"),
  BodyValues = list("NT-I-F",20210630,"CONSTANT_DENSITY"),
  .TableName. = "Numbers",
  .TableCols. = list("Age","Number"),
  .TableValues. = matrix(ncol=2,byrow=TRUE,data=list(
    0,	647,
    1,	2609,
    5,	3490,
    10,	3652,
    15,	3479,
    20,	3308,
    25,	3330,
    30,	3158,
    35,	2820,
    40,	2441,
    45,	2290,
    50,	2247,
    55,	1703,
    60,	1405,
    65,	910,
    70,	579,
    75,	247,
    80,	164,
    85,	106))
)


## -----------------------------------------------------------------------------
#
# Modify the pcurve object - change the BuildMethod
#
osr.ModifyObj(NULL,'NT-I-F_PCURVE_2021','PCURVE',NULL,'BuildMethod',NULL,'HYBRID_DENSITY')

## -----------------------------------------------------------------------------
osr.DisplayObj('NT-I-F_PCURVE_2021','PCURVE')

## -----------------------------------------------------------------------------
osr.GetObjInfo('NT-I-F_PCURVE_2021','PCURVE','BuildMethod')

## -----------------------------------------------------------------------------
osr.TotalNumber('NT-I-F_PCURVE_2021')
osr.MedianAge('NT-I-F_PCURVE_2021')

