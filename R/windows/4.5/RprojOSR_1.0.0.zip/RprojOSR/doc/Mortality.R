## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup, warning=FALSE, message=FALSE--------------------------------------
library(RprojOSR)
library(dplyr)
library(ggplot2)
library(flextable)

asdr <- aus_m_asdr_2011

osr.CreateObj(
  Handle = "AUS-M_ASDR_2011",
  ObjectType = "MORTALITY",
  BodyProps = list("Population","Date","BuildMethod"),
  BodyValues = list("AUS-M",20110601,"CONSTANT_FORCE"),
  .TableName. = "DeathRates",
  .TableCols. = list("Age","Rate"),
  .TableValues. = matrix(ncol=2,byrow=FALSE,data=c(asdr$age,asdr$rate))
)

## -----------------------------------------------------------------------------

BaseHandle <- 'AUS-M_ASDR_2011'

mort_objs <- tibble(
  BuildMethod = c('CONSTANT_FORCE',
                  'HELIGMAN_POLLARD',
                  'MALE_CALIBRATED_SPLINE:12000'
),
  Name = c('CONSTANT_FORCE',
                  'HELIGMAN_POLLARD',
                  'CS'
                  )) %>%
  group_by(BuildMethod) %>%
  mutate(
    Handle=osr.ModifyObj(Name,BaseHandle,'MORTALITY',NULL,'BuildMethod',NULL,BuildMethod)
  )

## ----fig.width=8,fig.height=6-------------------------------------------------

AgeInterval <- 1

mort_ages <- tibble(
  Age=seq(0,99,AgeInterval)
)

asdr_data <- mort_objs %>%
  cross_join(mort_ages) %>%
  group_by(Handle,Age) %>%
  mutate(ASDR=osr.DeathRate(Handle,Age,AgeInterval))

asdr_plot <- asdr_data %>%
  ggplot() +
  geom_line(aes(x=Age,y=ASDR,group=Name,colour=Name))+
  scale_y_log10()+
  theme_classic()+
  ggtitle('Expanded Death Rates')

asdr_plot

## ----tab.cap='Life Table, Australian Males, 2011'-----------------------------
Handle <- 'CS'

BigInterval <- 200
Radix <- 100000

lt_data <- tibble(
  Age = seq(0,100),
  AgeInterval=c(rep(1,100),BigInterval)
) %>% 
  group_by(Age) %>%
  mutate(SurvFrac=Radix*osr.SurvFrac(Handle,Age),
         DeathProb=osr.DeathProb(Handle,Age,AgeInterval),
         YearsLived=Radix*osr.YearsLived(Handle,Age,AgeInterval),
         YearsLivedAfter=osr.YearsLivedAfter(Handle,Age),
         LifeExp=osr.LifeExp(Handle,Age))

lt <- lt_data %>%
  flextable(
    col_keys = c("Age","SurvFrac","DeathProb","YearsLived","LifeExp")
  ) %>%
  # Header
  labelizor(
    labels = c("SurvFrac"="lx",
               "DeathProb"="qx",
               "YearsLived"="Lx",
               "LifeExp"="ex"),
    part="header"
  ) %>%
  # Body
  colformat_double(j=c('SurvFrac','YearsLived'),digits=0) %>%
  colformat_double(j=c('DeathProb','LifeExp'),digits=5) 


lt

