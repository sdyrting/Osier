## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup, warning=FALSE,message=FALSE---------------------------------------
library(RprojOSR)
library(dplyr)
library(ggplot2)

#
# 1Y out-migration probabilities and ratios for Victoria
#

asmp <- RprojOSR::vic_p_asmp_2010_2011
mratio <- RprojOSR::vic_p_mratio_2010_2011

mig_name <- "VIC-P_ASMP_MT_2010_2011"
  
osr.CreateObj(
  Handle = mig_name,
  ObjectType = "MIGRATION",
  BodyProps = list("Population","Date","BuildMethod","MultiTransBuildMethod"),
  BodyValues = list("VIC-P",20100630,"CONSTANT_INTENSITY","CONSTANT_RATIO"),
  .TableName. = "MigrationProbabilities",
  .TableCols. = list("Age","Probability","Use"),
  .TableValues. = as.matrix(asmp),
  .TableName2. = "MigrationRatios",
  .TableCols2. = names(mratio),
  .TableValues2. = as.matrix(mratio)
  )

## -----------------------------------------------------------------------------
smooth_mig_name <- paste0('S_',mig_name)
smooth_bm <- 'ROGERS_CASTRO_WILSON:"ErrType=POISSON","PCurve=VIC-P_N_PCURVE_2010_2011","A4=0","FitElderly=0"'
osr.ModifyObj(smooth_mig_name,mig_name,'MIGRATION',,'BuildMethod',,smooth_bm)

## -----------------------------------------------------------------------------
#
# Population exposed to out-migration
#

num <- vic_p_num_2010_2011

osr.CreateObj(
  Handle = "VIC-P_N_PCURVE_2010_2011",
  ObjectType = "PCURVE",
  BodyProps = list("Population","Date","BuildMethod"),
  BodyValues = list("VIC-P",20100630,"CONSTANT_DENSITY"),
  .TableName. = "Numbers",
  .TableCols. = list("Age","Number","Use"),
  .TableValues. = as.matrix(num)
)

## -----------------------------------------------------------------------------
smooth_mtbm <- 'PSPLINE:"VIC-P_M_PCURVE_2010_2011"'
osr.ModifyObj(NULL,smooth_mig_name,'MIGRATION',,'MultiTransBuildMethod',,smooth_mtbm)

## -----------------------------------------------------------------------------
#
# Numbers of movers
#

mov <- vic_p_mov_2010_2011

osr.CreateObj(
  Handle = "VIC-P_M_PCURVE_2010_2011",
  ObjectType = "PCURVE",
  BodyProps = list("Population","Date","BuildMethod"),
  BodyValues = list("VIC-P",20100630,"CONSTANT_DENSITY"),
  .TableName. = "Numbers",
  .TableCols. = list("Age","Number","Use"),
  .TableValues. = as.matrix(mov)
)


## ----fig.cap='Destination-specific out-migration probabilities, Victoria, 2010-2011',fig.width=8,fig.height=6----
ToPop <- names(mratio)
ToPop <- ToPop[!ToPop %in% c('Age','Use')]

mprob_fig <- tibble(
  Name=c(mig_name,smooth_mig_name),
  Type=c('Raw','Smoothed')) %>%
  cross_join(tibble(Age=seq(0,99))) %>%
  cross_join(tibble(ToPop=ToPop)) %>%
  group_by(Name,Age,ToPop) %>%
  mutate(mprob=osr.MigrationProb(Name,Age,,ToPop)) %>%
  ggplot()+
  geom_line(aes(x=Age,y=mprob,group=Type,colour=Type))+
  facet_wrap(vars(ToPop))

mprob_fig <- mprob_fig +
  theme_classic() +
  labs(x="Age",y="Migration Probability")
  

mprob_fig

