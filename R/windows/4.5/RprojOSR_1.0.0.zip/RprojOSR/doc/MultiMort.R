## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup, warning=FALSE,message=FALSE---------------------------------------
library(RprojOSR)
library(dplyr)
library(ggplot2)

md_mort_name <- 'USA-F_MORT_2023'
drates <- RprojOSR::usa_f_drates_2023
dratio <- RprojOSR::usa_f_dratio_2023

osr.CreateObj(md_mort_name,'MORTALITY',
              BodyProps = c('Population','Date','BuildMethod','MultiDecBuildMethod'),
              BodyValues = list('USA-F',20230630,'HELIGMAN_POLLARD8','HYBRID_RATIO'),
              .TableName. = 'DeathRates',
              .TableCols. = names(drates),
              .TableValues. = as.matrix(drates),
              .TableName2. = 'DeathRatios',
              .TableCols2. = names(dratio),
              .TableValues2. = as.matrix(dratio)
)

## ----fig.width=8,fig.height=6-------------------------------------------------

broad_causes <- tibble(
  cause_code = c('S007','S002','S006','S010,S011','S016','~S007,S002,S006,S010,S011,S016'),
  Cause = c('Heart diseases',
                 'Neoplasms',
                 'Diseases of the nervous system \nand the sense organs',
                 'Respiratory diseases',
                 'External causes',
                 'Other')
) %>% mutate(Cause=factor(Cause,levels=Cause))

ages <- tibble(
  Age=seq(0,110)
)

deaths_plot <- ages %>%
  cross_join(broad_causes) %>%
  group_by(cause_code,Age) %>%
  mutate(Deaths=osr.Deaths(md_mort_name,Age,NULL,cause_code)) %>%
  ggplot()+
  geom_line(aes(x=Age,y=Deaths,group=Cause,colour=Cause))+
  theme_classic()+
  labs(title='Life table deaths by cause, USA females 2023')

deaths_plot


