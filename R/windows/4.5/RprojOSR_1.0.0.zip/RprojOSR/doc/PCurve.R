## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup, warning=FALSE,message=FALSE---------------------------------------
library(RprojOSR)
library(dplyr)
library(ggplot2)

#
# Female overseas arrival to the NT, financial year 2023-24
#


nom_arr <- nt_f_nom_arr_fy2024

osr.CreateObj(
  Handle = "NT-F_NOM_ARR_PCURVE_FY2024",
  ObjectType = "PCURVE",
  BodyProps = list("Population","Date","BuildMethod","Source","Comment"),
  BodyValues = list("NT-P",20240630,"CONSTANT_DENSITY","ABS","NOM Arrivals by calendar year"),
  .TableName. = "Numbers",
  .TableCols. = list("Age","Number"),
  .TableValues. = matrix(ncol=2,byrow=FALSE,data=c(nom_arr$age,nom_arr$number))
)


## -----------------------------------------------------------------------------
  
#
# Female overseas arrivals to Australia, financial year 2023-24
#

std_nom_arr <- aus_f_nom_arr_fy2024

osr.CreateObj(
  Handle = "AUS-F_NOM_ARR_PCURVE_FY2024",
  ObjectType = "PCURVE",
  BodyProps = list("Population","Date","BuildMethod"),
  BodyValues = list("AUS-F",20240630,'HYBRID_EXPONENTIAL'),
  .TableName. = "Numbers",
  .TableCols. = list("Age","Number"),
  .TableValues. = matrix(ncol=2,byrow=FALSE,data=c(std_nom_arr$age,std_nom_arr$number))
)

## ----fig.width=8--------------------------------------------------------------
pcurve_ages <- tibble(
  Age=seq(0,100)
)

std_plot <- pcurve_ages %>%
  group_by(Age) %>%
  mutate(Number=osr.Number("AUS-F_NOM_ARR_PCURVE_FY2024",Age)) %>%
  ggplot()+
  geom_line(aes(x=Age,y=Number))+
  ggtitle("Female overseas arrivals by age, Australia 2023-24")+
  ylab("Number")+
  theme_classic()

std_plot

## ----fig.width=8--------------------------------------------------------------

BaseHandle <- "NT-F_NOM_ARR_PCURVE_FY2024"

pcurve_objs <- tibble(
  BuildMethod = c('CONSTANT_DENSITY',
                  'PTOPALS:"ErrType=NORMAL","Var=8.333","Standard=AUS-F_NOM_ARR_PCURVE_FY2024","MaxIts=20"'
                  ),
  Name=c('Published','Expanded')) %>%
  group_by(BuildMethod) %>%
  mutate(Handle=osr.ModifyObj(Name,BaseHandle,'PCURVE',NULL,'BuildMethod',NULL,BuildMethod))

num_data <- pcurve_objs %>%
  cross_join(pcurve_ages) %>%
  group_by(Name,Age) %>%
  mutate(Number=osr.Number(Handle,Age))

interp_num_fig <- num_data %>%
  ggplot() +
  geom_line(aes(x=Age,y=Number,group=Name,colour=Name))+
  theme_classic()+
  ggtitle("Female overseas arrivals by age, Northern Territory 2023-24")

interp_num_fig

