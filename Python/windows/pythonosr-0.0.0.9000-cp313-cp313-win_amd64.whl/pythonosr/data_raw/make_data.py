import pyreadr
import glob
import re

rda_files = glob.glob('./*.rda')
for rda_file in rda_files :
    df_name=re.findall(r'(\w+)\.',rda_file)[0]
    csv_file='../data/'+df_name+'.csv'
    df = pyreadr.read_r(rda_file)[df_name]
    df.to_csv(csv_file,index=False)