import PythonOSR

def LoadLibrary(library=""):
	"""Loads a library supporting the wlox interface
	
	Args:
		library: the name of the shares library. Optional. Defaults to \"\"
		
	"""
	return PythonOSR.loadLibrary(library)

def NewFunction(name,count):
	"""Creates a new function handle
	
	Args:
		name: the name of the function
		count: the number of function arguments
		
	"""
	return PythonOSR.newFunction(name,count)

def AddParameter(name,i,arg):
	"""Adds a argument value to a function
	
	Args:
		name: the name of the function
		i: the index of the argument
		arg: the value of the argument
		
	"""
	return PythonOSR.addParameter(name,i,arg)

def MakeFunctionCall(name):
	"""Makes a call to a function.
	
	Args:
		name: The name of the function
		
	"""
	return PythonOSR.makeFunctionCall(name)

def GetError():
	"""Returns the error message for the last function call."""	
	return PythonOSR.getError()

def ErrorFlag():
	"""Flags an error in the last function call
	
	Returns:
		bool: True if last function call returned an error else False
		
	"""
	return PythonOSR.errorFlag()

def Osier():
	"""Osier version

	"""
	func=PythonOSR.newFunction('Osier',0)
	return PythonOSR.makeFunctionCall(func)


def ColSort(Range=None,_SortCol_=None,_Ascend_=None):
	"""Sorts rows of a range by a specified colum.

	Args:
		Range: The range
		_SortCol_: Optional. The column to sort by. Defaults to 1
		_Ascend_: Optional. If <> 0 then sorts in ascending order, else if == 0 sorts descending. Defaults to 1

	"""
	func=PythonOSR.newFunction('ColSort',3)
	retval=PythonOSR.addParameter(func,0,Range)
	retval=PythonOSR.addParameter(func,1,_SortCol_)
	retval=PythonOSR.addParameter(func,2,_Ascend_)
	return PythonOSR.makeFunctionCall(func)


def Resize(Range=None,Rows=None,Cols=None):
	"""Resizes an Excel range

	Args:
		Range: The range
		Rows: Number of rows
		Cols: Number of cols

	"""
	func=PythonOSR.newFunction('Resize',3)
	retval=PythonOSR.addParameter(func,0,Range)
	retval=PythonOSR.addParameter(func,1,Rows)
	retval=PythonOSR.addParameter(func,2,Cols)
	return PythonOSR.makeFunctionCall(func)


def MakeVector(_Val1_=None,_Val2_=None,_Val3_=None,_Val4_=None,_Val5_=None,_Val6_=None,_Val7_=None,_Val8_=None,_Val9_=None,_Val10_=None,_Val11_=None,_Val12_=None,_Val13_=None,_Val14_=None,_Val15_=None,_Val16_=None,_Val17_=None,_Val18_=None,_Val19_=None,_Val20_=None):
	"""Makes a vector from a set of elements

	Args:
		_Val1_: Optional. If not specified then not added to vector
		_Val2_: Optional. If not specified then not added to vector
		_Val3_: Optional. If not specified then not added to vector
		_Val4_: Optional. If not specified then not added to vector
		_Val5_: Optional. If not specified then not added to vector
		_Val6_: Optional. If not specified then not added to vector
		_Val7_: Optional. If not specified then not added to vector
		_Val8_: Optional. If not specified then not added to vector
		_Val9_: Optional. If not specified then not added to vector
		_Val10_: Optional. If not specified then not added to vector
		_Val11_: Optional. If not specified then not added to vector
		_Val12_: Optional. If not specified then not added to vector
		_Val13_: Optional. If not specified then not added to vector
		_Val14_: Optional. If not specified then not added to vector
		_Val15_: Optional. If not specified then not added to vector
		_Val16_: Optional. If not specified then not added to vector
		_Val17_: Optional. If not specified then not added to vector
		_Val18_: Optional. If not specified then not added to vector
		_Val19_: Optional. If not specified then not added to vector
		_Val20_: Optional. If not specified then not added to vector

	"""
	func=PythonOSR.newFunction('MakeVector',20)
	retval=PythonOSR.addParameter(func,0,_Val1_)
	retval=PythonOSR.addParameter(func,1,_Val2_)
	retval=PythonOSR.addParameter(func,2,_Val3_)
	retval=PythonOSR.addParameter(func,3,_Val4_)
	retval=PythonOSR.addParameter(func,4,_Val5_)
	retval=PythonOSR.addParameter(func,5,_Val6_)
	retval=PythonOSR.addParameter(func,6,_Val7_)
	retval=PythonOSR.addParameter(func,7,_Val8_)
	retval=PythonOSR.addParameter(func,8,_Val9_)
	retval=PythonOSR.addParameter(func,9,_Val10_)
	retval=PythonOSR.addParameter(func,10,_Val11_)
	retval=PythonOSR.addParameter(func,11,_Val12_)
	retval=PythonOSR.addParameter(func,12,_Val13_)
	retval=PythonOSR.addParameter(func,13,_Val14_)
	retval=PythonOSR.addParameter(func,14,_Val15_)
	retval=PythonOSR.addParameter(func,15,_Val16_)
	retval=PythonOSR.addParameter(func,16,_Val17_)
	retval=PythonOSR.addParameter(func,17,_Val18_)
	retval=PythonOSR.addParameter(func,18,_Val19_)
	retval=PythonOSR.addParameter(func,19,_Val20_)
	return PythonOSR.makeFunctionCall(func)


def MakeMatrix(Rows=None,Columns=None,_Val1_=None,_Val2_=None,_Val3_=None,_Val4_=None,_Val5_=None,_Val6_=None,_Val7_=None,_Val8_=None,_Val9_=None,_Val10_=None,_Val11_=None,_Val12_=None,_Val13_=None,_Val14_=None,_Val15_=None,_Val16_=None,_Val17_=None,_Val18_=None):
	"""Makes a matrix from a set of elements

	Args:
		Rows: The number of rows
		Columns: The number of columns
		_Val1_: Optional. If not specified then not added to matrix
		_Val2_: Optional. If not specified then not added to matrix
		_Val3_: Optional. If not specified then not added to matrix
		_Val4_: Optional. If not specified then not added to matrix
		_Val5_: Optional. If not specified then not added to matrix
		_Val6_: Optional. If not specified then not added to matrix
		_Val7_: Optional. If not specified then not added to matrix
		_Val8_: Optional. If not specified then not added to matrix
		_Val9_: Optional. If not specified then not added to matrix
		_Val10_: Optional. If not specified then not added to matrix
		_Val11_: Optional. If not specified then not added to matrix
		_Val12_: Optional. If not specified then not added to matrix
		_Val13_: Optional. If not specified then not added to matrix
		_Val14_: Optional. If not specified then not added to matrix
		_Val15_: Optional. If not specified then not added to matrix
		_Val16_: Optional. If not specified then not added to matrix
		_Val17_: Optional. If not specified then not added to matrix
		_Val18_: Optional. If not specified then not added to matrix

	"""
	func=PythonOSR.newFunction('MakeMatrix',20)
	retval=PythonOSR.addParameter(func,0,Rows)
	retval=PythonOSR.addParameter(func,1,Columns)
	retval=PythonOSR.addParameter(func,2,_Val1_)
	retval=PythonOSR.addParameter(func,3,_Val2_)
	retval=PythonOSR.addParameter(func,4,_Val3_)
	retval=PythonOSR.addParameter(func,5,_Val4_)
	retval=PythonOSR.addParameter(func,6,_Val5_)
	retval=PythonOSR.addParameter(func,7,_Val6_)
	retval=PythonOSR.addParameter(func,8,_Val7_)
	retval=PythonOSR.addParameter(func,9,_Val8_)
	retval=PythonOSR.addParameter(func,10,_Val9_)
	retval=PythonOSR.addParameter(func,11,_Val10_)
	retval=PythonOSR.addParameter(func,12,_Val11_)
	retval=PythonOSR.addParameter(func,13,_Val12_)
	retval=PythonOSR.addParameter(func,14,_Val13_)
	retval=PythonOSR.addParameter(func,15,_Val14_)
	retval=PythonOSR.addParameter(func,16,_Val15_)
	retval=PythonOSR.addParameter(func,17,_Val16_)
	retval=PythonOSR.addParameter(func,18,_Val17_)
	retval=PythonOSR.addParameter(func,19,_Val18_)
	return PythonOSR.makeFunctionCall(func)


def Append(Range1=None,Range2=None,_Range3_=None,_Range4_=None):
	"""Appends up to three range on to the end of a range.

	Args:
		Range1: The starting range
		Range2: The range to append to the end of the starting range
		_Range3_: Optional. If specified then will be appended after Range2.
		_Range4_: Optional. If specified then will be appended after Range3.

	"""
	func=PythonOSR.newFunction('Append',4)
	retval=PythonOSR.addParameter(func,0,Range1)
	retval=PythonOSR.addParameter(func,1,Range2)
	retval=PythonOSR.addParameter(func,2,_Range3_)
	retval=PythonOSR.addParameter(func,3,_Range4_)
	return PythonOSR.makeFunctionCall(func)


def WLTranspose(Range=None):
	"""Returns the transpose of a range.

	Args:
		Range: The range

	"""
	func=PythonOSR.newFunction('WLTranspose',1)
	retval=PythonOSR.addParameter(func,0,Range)
	return PythonOSR.makeFunctionCall(func)


def MakeGrid(Rows=None,Columns=None,Range=None):
	"""Uses Range to make a Rows-by-Columns grid.

	Args:
		Rows: The number of rows
		Columns: The number of columns
		Range: The range

	"""
	func=PythonOSR.newFunction('MakeGrid',3)
	retval=PythonOSR.addParameter(func,0,Rows)
	retval=PythonOSR.addParameter(func,1,Columns)
	retval=PythonOSR.addParameter(func,2,Range)
	return PythonOSR.makeFunctionCall(func)


def MatrixToList(RowLabels=None,ColumnLabels=None,Matrix=None):
	"""Constructs a list from a matrix with labelled rows and columns. The inverse of ListToMatrix

	Args:
		RowLabels: The row labels
		ColumnLabels: The column labels
		Matrix: The matrix

	"""
	func=PythonOSR.newFunction('MatrixToList',3)
	retval=PythonOSR.addParameter(func,0,RowLabels)
	retval=PythonOSR.addParameter(func,1,ColumnLabels)
	retval=PythonOSR.addParameter(func,2,Matrix)
	return PythonOSR.makeFunctionCall(func)


def ListToMatrix(RowLabels=None,ColumnLabels=None,Values=None,_LabelType_=None):
	"""Constructs a matrix from a lists of row labels, column labels and values. The inverse of MatrixToList

	Args:
		RowLabels: The row labels
		ColumnLabels: The column labels
		Values: The values
		_LabelType_: Optional. The type of label. Can be 'NUMBER', 'DATE', 'STRING' or 'INTERVAL'. Defaults to 'NUMBER'.

	"""
	func=PythonOSR.newFunction('ListToMatrix',4)
	retval=PythonOSR.addParameter(func,0,RowLabels)
	retval=PythonOSR.addParameter(func,1,ColumnLabels)
	retval=PythonOSR.addParameter(func,2,Values)
	retval=PythonOSR.addParameter(func,3,_LabelType_)
	return PythonOSR.makeFunctionCall(func)


def FillMatrix(XRange=None,YRange=None,Matrix=None,_InterpMethod_=None):
	"""Fills missing values in a matrix by 2D interpolation

	Args:
		XRange: X values for each column
		YRange: Y values for each row
		Matrix: The matrix
		_InterpMethod_: Optional. The interpolation method. Can be 1, 2, or 3. Defaults to 1.

	"""
	func=PythonOSR.newFunction('FillMatrix',4)
	retval=PythonOSR.addParameter(func,0,XRange)
	retval=PythonOSR.addParameter(func,1,YRange)
	retval=PythonOSR.addParameter(func,2,Matrix)
	retval=PythonOSR.addParameter(func,3,_InterpMethod_)
	return PythonOSR.makeFunctionCall(func)


def InterpMatrixValue(XRange=None,YRange=None,Matrix=None,XValue=None,YValue=None,_InterpMethod_=None):
	"""Interpolates from [XRange,YRange] to (XValue,YValue)

	Args:
		XRange: The X range to interpolate from
		YRange: The Y range to interpolate from
		Matrix: The matrix of values to interpolate from
		XValue: The X value to interpolate to
		YValue: The Y value to interpolate to
		_InterpMethod_: Optional. The interpolation method. Defaults to 1

	"""
	func=PythonOSR.newFunction('InterpMatrixValue',6)
	retval=PythonOSR.addParameter(func,0,XRange)
	retval=PythonOSR.addParameter(func,1,YRange)
	retval=PythonOSR.addParameter(func,2,Matrix)
	retval=PythonOSR.addParameter(func,3,XValue)
	retval=PythonOSR.addParameter(func,4,YValue)
	retval=PythonOSR.addParameter(func,5,_InterpMethod_)
	return PythonOSR.makeFunctionCall(func)


def MatrixInterp(YValue=None,XValue=None,Matrix=None):
	"""Interpolates a matrix to (XValue,YValue) using bilinear method

	Args:
		YValue: The Y value to interpolate to
		XValue: The X value to interpolate to
		Matrix: The matrix to interpolate from

	"""
	func=PythonOSR.newFunction('MatrixInterp',3)
	retval=PythonOSR.addParameter(func,0,YValue)
	retval=PythonOSR.addParameter(func,1,XValue)
	retval=PythonOSR.addParameter(func,2,Matrix)
	return PythonOSR.makeFunctionCall(func)


def LineInt(XRange=None,YRange=None,XValues=None,_InterpOrder_=None,_InterpMode_=None,_Tension_=None):
	"""Interpolates from [XRange,YRange] to XValues

	Args:
		XRange: The range of X values to interpolate from
		YRange: The range of Y values to interpolate from
		XValues: The range of X values to interpolate to
		_InterpOrder_: Optional. The order of the spline interpolation. Defaults to 1. Linear spline
		_InterpMode_: Optional. The way XRange and YRange are transformed prior to splining. Defaults to 0. No transformation.
		_Tension_: Optional. The tension applied to Cubic splines. Defaults to 0.0

	"""
	func=PythonOSR.newFunction('LineInt',6)
	retval=PythonOSR.addParameter(func,0,XRange)
	retval=PythonOSR.addParameter(func,1,YRange)
	retval=PythonOSR.addParameter(func,2,XValues)
	retval=PythonOSR.addParameter(func,3,_InterpOrder_)
	retval=PythonOSR.addParameter(func,4,_InterpMode_)
	retval=PythonOSR.addParameter(func,5,_Tension_)
	return PythonOSR.makeFunctionCall(func)


def CountryNumToAlpha3(Numeric=None,_CodeHandle_=None):
	"""Given the numeric country code returns the corresponding 3-letter code

	Args:
		Numeric: The numeric country code
		_CodeHandle_: Optional. Results handle with ResultsType=COUNTRYCODE. Defaults to ISO3166-1

	"""
	func=PythonOSR.newFunction('CountryNumToAlpha3',2)
	retval=PythonOSR.addParameter(func,0,Numeric)
	retval=PythonOSR.addParameter(func,1,_CodeHandle_)
	return PythonOSR.makeFunctionCall(func)


def CountryNumToAlpha2(Numeric=None,_CodeHandle_=None):
	"""Given the numeric country code returns the corresponding 2-letter code

	Args:
		Numeric: The numeric country code
		_CodeHandle_: Optional. Results handle with ResultsType=COUNTRYCODE. Defaults to ISO3166-1

	"""
	func=PythonOSR.newFunction('CountryNumToAlpha2',2)
	retval=PythonOSR.addParameter(func,0,Numeric)
	retval=PythonOSR.addParameter(func,1,_CodeHandle_)
	return PythonOSR.makeFunctionCall(func)


def CountryNumToName(Numeric=None,_CodeHandle_=None):
	"""Given the numeric country code returns the corresponding country name

	Args:
		Numeric: The numeric country code
		_CodeHandle_: Optional. Results handle with ResultsType=COUNTRYCODE. Defaults to ISO3166-1

	"""
	func=PythonOSR.newFunction('CountryNumToName',2)
	retval=PythonOSR.addParameter(func,0,Numeric)
	retval=PythonOSR.addParameter(func,1,_CodeHandle_)
	return PythonOSR.makeFunctionCall(func)


def CountryAlpha3ToNum(Alpha3=None,_CodeHandle_=None):
	"""Given the country code returns the corresponding numeric code

	Args:
		Alpha3: The Alpha-3 country code
		_CodeHandle_: Optional. Results handle with ResultsType=COUNTRYCODE. Defaults to ISO3166-1

	"""
	func=PythonOSR.newFunction('CountryAlpha3ToNum',2)
	retval=PythonOSR.addParameter(func,0,Alpha3)
	retval=PythonOSR.addParameter(func,1,_CodeHandle_)
	return PythonOSR.makeFunctionCall(func)


def CountryAlpha2ToNum(Alpha2=None,_CodeHandle_=None):
	"""Given the 2-letter country code returns the corresponding numeric code

	Args:
		Alpha2: The Alpha-2 country code
		_CodeHandle_: Optional. Results handle with ResultsType=COUNTRYCODE. Defaults to ISO3166-1

	"""
	func=PythonOSR.newFunction('CountryAlpha2ToNum',2)
	retval=PythonOSR.addParameter(func,0,Alpha2)
	retval=PythonOSR.addParameter(func,1,_CodeHandle_)
	return PythonOSR.makeFunctionCall(func)


def CountryNameToNum(Name=None,_CodeHandle_=None):
	"""Given the country code name returns the corresponding numeric code

	Args:
		Name: Country Name
		_CodeHandle_: Optional. Results handle with ResultsType=COUNTRYCODE. Defaults to ISO3166-1

	"""
	func=PythonOSR.newFunction('CountryNameToNum',2)
	retval=PythonOSR.addParameter(func,0,Name)
	retval=PythonOSR.addParameter(func,1,_CodeHandle_)
	return PythonOSR.makeFunctionCall(func)


def CreateObj(Handle=None,ObjectType=None,BodyProps=None,BodyValues=None,_TableName_=None,_TableCols_=None,_TableValues_=None,_TableName2_=None,_TableCols2_=None,_TableValues2_=None,_TableName3_=None,_TableCols3_=None,_TableValues3_=None,_TableName4_=None,_TableCols4_=None,_TableValues4_=None,_TableName5_=None,_TableCols5_=None,_TableValues5_=None):
	"""Creates an object

	Args:
		Handle: The name of the object to create
		ObjectType: The type of object to create
		BodyProps: A list of property names
		BodyValues: A matrix of property values
		_TableName_: Name of a table
		_TableCols_: Columns names of the table
		_TableValues_: Table values
		_TableName2_: Name of a table 2
		_TableCols2_: Columns names of the table 2
		_TableValues2_: Table 2 values
		_TableName3_: Name of a table 3
		_TableCols3_: Columns names of the table 3
		_TableValues3_: Table 3 values
		_TableName4_: Name of a table 4
		_TableCols4_: Columns names of the table 4
		_TableValues4_: Table 4 values
		_TableName5_: Name of a table 5
		_TableCols5_: Columns names of the table 5
		_TableValues5_: Table 5 values

	"""
	func=PythonOSR.newFunction('CreateObj',19)
	retval=PythonOSR.addParameter(func,0,Handle)
	retval=PythonOSR.addParameter(func,1,ObjectType)
	retval=PythonOSR.addParameter(func,2,BodyProps)
	retval=PythonOSR.addParameter(func,3,BodyValues)
	retval=PythonOSR.addParameter(func,4,_TableName_)
	retval=PythonOSR.addParameter(func,5,_TableCols_)
	retval=PythonOSR.addParameter(func,6,_TableValues_)
	retval=PythonOSR.addParameter(func,7,_TableName2_)
	retval=PythonOSR.addParameter(func,8,_TableCols2_)
	retval=PythonOSR.addParameter(func,9,_TableValues2_)
	retval=PythonOSR.addParameter(func,10,_TableName3_)
	retval=PythonOSR.addParameter(func,11,_TableCols3_)
	retval=PythonOSR.addParameter(func,12,_TableValues3_)
	retval=PythonOSR.addParameter(func,13,_TableName4_)
	retval=PythonOSR.addParameter(func,14,_TableCols4_)
	retval=PythonOSR.addParameter(func,15,_TableValues4_)
	retval=PythonOSR.addParameter(func,16,_TableName5_)
	retval=PythonOSR.addParameter(func,17,_TableCols5_)
	retval=PythonOSR.addParameter(func,18,_TableValues5_)
	return PythonOSR.makeFunctionCall(func)


def CloneObj(_NewHandle_=None,Handle=None,ObjectType=None,_Body_=None,_TableName_=None,_TableBody_=None,_TableName2_=None,_TableBody2_=None,_TableName3_=None,_TableBody3_=None,_TableName4_=None,_TableBody4_=None,_TableName5_=None,_TableBody5_=None):
	"""Duplicates an object with the option of adding subtables

	Args:
		_NewHandle_: Name of the new object. Optional. Defaults to Handle
		Handle: Name of the object duplicated
		ObjectType: Type of the object duplicated
		_Body_: Optional. The new body
		_TableName_: Optional. The name of a subtable
		_TableBody_: Optional. The new body body of new subtable. If missing the subtable is removed from the object
		_TableName2_: Optional. The name of a subtable
		_TableBody2_: Optional. The new body body of new subtable. If missing the subtable is removed from the object
		_TableName3_: Optional. The name of a subtable
		_TableBody3_: Optional. The new body body of new subtable. If missing the subtable is removed from the object
		_TableName4_: Optional. The name of a subtable
		_TableBody4_: Optional. The new body body of new subtable. If missing the subtable is removed from the object
		_TableName5_: Optional. The name of a subtable
		_TableBody5_: Optional. The new body body of new subtable. If missing the subtable is removed from the object

	"""
	func=PythonOSR.newFunction('CloneObj',14)
	retval=PythonOSR.addParameter(func,0,_NewHandle_)
	retval=PythonOSR.addParameter(func,1,Handle)
	retval=PythonOSR.addParameter(func,2,ObjectType)
	retval=PythonOSR.addParameter(func,3,_Body_)
	retval=PythonOSR.addParameter(func,4,_TableName_)
	retval=PythonOSR.addParameter(func,5,_TableBody_)
	retval=PythonOSR.addParameter(func,6,_TableName2_)
	retval=PythonOSR.addParameter(func,7,_TableBody2_)
	retval=PythonOSR.addParameter(func,8,_TableName3_)
	retval=PythonOSR.addParameter(func,9,_TableBody3_)
	retval=PythonOSR.addParameter(func,10,_TableName4_)
	retval=PythonOSR.addParameter(func,11,_TableBody4_)
	retval=PythonOSR.addParameter(func,12,_TableName5_)
	retval=PythonOSR.addParameter(func,13,_TableBody5_)
	return PythonOSR.makeFunctionCall(func)


def DeleteObjs(_Handles_=None,ObjectType=None):
	"""Deletes objects from object pool

	Args:
		_Handles_: The names of the objects to delete. If missing deletes all objects of specified type
		ObjectType: The type of objects to delete. If empty string then deletes all objectes

	"""
	func=PythonOSR.newFunction('DeleteObjs',2)
	retval=PythonOSR.addParameter(func,0,_Handles_)
	retval=PythonOSR.addParameter(func,1,ObjectType)
	return PythonOSR.makeFunctionCall(func)


def DisplayObj(Handle=None,ObjectType=None):
	"""Displays an object

	Args:
		Handle: The name of the object to display
		ObjectType: The type of object to display

	"""
	func=PythonOSR.newFunction('DisplayObj',2)
	retval=PythonOSR.addParameter(func,0,Handle)
	retval=PythonOSR.addParameter(func,1,ObjectType)
	return PythonOSR.makeFunctionCall(func)


def DisplayObjLabels(Handle=None,ObjectType=None,_TableName_=None):
	"""List property names in an objects body or subtable

	Args:
		Handle: Name of the object
		ObjectType: Type of the object
		_TableName_: Optional. If specified the function returns the subtables column headings. Otherwise return body property names

	"""
	func=PythonOSR.newFunction('DisplayObjLabels',3)
	retval=PythonOSR.addParameter(func,0,Handle)
	retval=PythonOSR.addParameter(func,1,ObjectType)
	retval=PythonOSR.addParameter(func,2,_TableName_)
	return PythonOSR.makeFunctionCall(func)


def DisplaySubtableNames(Handle=None,ObjectType=None):
	"""List names of the subtables in an object

	Args:
		Handle: Name of the object
		ObjectType: Type of the object

	"""
	func=PythonOSR.newFunction('DisplaySubtableNames',2)
	retval=PythonOSR.addParameter(func,0,Handle)
	retval=PythonOSR.addParameter(func,1,ObjectType)
	return PythonOSR.makeFunctionCall(func)


def GetObj(Handle=None,ObjectType=None):
	"""Returns the handle and instance of an objet or an error message if the object does not exist. This function is volatile

	Args:
		Handle: Name of the object
		ObjectType: Type of the object

	"""
	func=PythonOSR.newFunction('GetObj',2)
	retval=PythonOSR.addParameter(func,0,Handle)
	retval=PythonOSR.addParameter(func,1,ObjectType)
	return PythonOSR.makeFunctionCall(func)


def GetObjInfo(Handle=None,ObjectType=None,Property=None,_PropertyNumber_=None,_ColumnName_=None,_RowNumber_=None):
	"""Returns the value of a body property or a subtable column

	Args:
		Handle: Name of the object
		ObjectType: Type of the object
		Property: Name of the body property or subtable
		_PropertyNumber_: Optional. Number of the property value. Defaults to 0 if not specified. If < 0 then returns the entire property value vector.
		_ColumnName_: Optional. The name of column of a subtable. If not specified the function will return a body property value
		_RowNumber_: Optional. Rownumber of the property in a subtable. Defaults to 0 if not specified. If <0 then returns the entire column vector.

	"""
	func=PythonOSR.newFunction('GetObjInfo',6)
	retval=PythonOSR.addParameter(func,0,Handle)
	retval=PythonOSR.addParameter(func,1,ObjectType)
	retval=PythonOSR.addParameter(func,2,Property)
	retval=PythonOSR.addParameter(func,3,_PropertyNumber_)
	retval=PythonOSR.addParameter(func,4,_ColumnName_)
	retval=PythonOSR.addParameter(func,5,_RowNumber_)
	return PythonOSR.makeFunctionCall(func)


def GridToObject(Handle=None,ObjectType=None,Grid=None):
	"""Creates and object from a grid

	Args:
		Handle: Name of the object
		ObjectType: Type of the object
		Grid: The grid

	"""
	func=PythonOSR.newFunction('GridToObject',3)
	retval=PythonOSR.addParameter(func,0,Handle)
	retval=PythonOSR.addParameter(func,1,ObjectType)
	retval=PythonOSR.addParameter(func,2,Grid)
	return PythonOSR.makeFunctionCall(func)


def ListObjs(_ObjectType_=None):
	"""Lists all objects of specified type

	Args:
		_ObjectType_: Optional. The type of the objects to display.

	"""
	func=PythonOSR.newFunction('ListObjs',1)
	retval=PythonOSR.addParameter(func,0,_ObjectType_)
	return PythonOSR.makeFunctionCall(func)


def LoadObjs(_Handles_=None,_TargetType_=None,FileName=None):
	"""Loads objects from a file

	Args:
		_Handles_: Optional. A regular expression for the handles to be loaded
		_TargetType_: Optional. A regular expression for the types to be loaded.
		FileName: The full pathname of the file to load the objects from.

	"""
	func=PythonOSR.newFunction('LoadObjs',3)
	retval=PythonOSR.addParameter(func,0,_Handles_)
	retval=PythonOSR.addParameter(func,1,_TargetType_)
	retval=PythonOSR.addParameter(func,2,FileName)
	return PythonOSR.makeFunctionCall(func)


def ModifyObj(_NewHandle_=None,Handle=None,ObjectType=None,_TableName_=None,_ColName_=None,_RowNum_=None,_Vals_=None,_TableName2_=None,_ColName2_=None,_RowNum2_=None,_Vals2_=None,_TableName3_=None,_ColName3_=None,_RowNum3_=None,_Vals3_=None,_TableName4_=None,_ColName4_=None,_RowNum4_=None,_Vals4_=None):
	"""Modify property values of an object, with the option of creating a new object

	Args:
		_NewHandle_: Optional. The name of the new object to create.
		Handle: The handle of the object to modify.
		ObjectType: The type of the object to modify.
		_TableName_: Optional. The name of the subtable to modify. If not specified the body is modified
		_ColName_: Optional. If not given and TableName was specified, drops the whole subtable. Else modifies that property or column within the subtable.
		_RowNum_: Optional. The row to start modifications at. Value -1 means to fill the column with the single value given. Defaults to 0.
		_Vals_: Optional. If not given, drops the column within the subtable. Else the table is modified using as many values as are given.
		_TableName2_: Optional. The name of the subtable to modify. If not specified the body is modified
		_ColName2_: Optional. If not given and TableName was specified, drops the whole subtable. Else modifies that property or column within the subtable.
		_RowNum2_: Optional. The row to start modifications at. Value -1 means to fill the column with the single value given. Defaults to 0.
		_Vals2_: Optional. If not given, drops the column within the subtable. Else the table is modified using as many values as are given.
		_TableName3_: Optional. The name of the subtable to modify. If not specified the body is modified
		_ColName3_: Optional. If not given and TableName was specified, drops the whole subtable. Else modifies that property or column within the subtable.
		_RowNum3_: Optional. The row to start modifications at. Value -1 means to fill the column with the single value given. Defaults to 0.
		_Vals3_: Optional. If not given, drops the column within the subtable. Else the table is modified using as many values as are given.
		_TableName4_: Optional. The name of the subtable to modify. If not specified the body is modified
		_ColName4_: Optional. If not given and TableName was specified, drops the whole subtable. Else modifies that property or column within the subtable.
		_RowNum4_: Optional. The row to start modifications at. Value -1 means to fill the column with the single value given. Defaults to 0.
		_Vals4_: Optional. If not given, drops the column within the subtable. Else the table is modified using as many values as are given.

	"""
	func=PythonOSR.newFunction('ModifyObj',19)
	retval=PythonOSR.addParameter(func,0,_NewHandle_)
	retval=PythonOSR.addParameter(func,1,Handle)
	retval=PythonOSR.addParameter(func,2,ObjectType)
	retval=PythonOSR.addParameter(func,3,_TableName_)
	retval=PythonOSR.addParameter(func,4,_ColName_)
	retval=PythonOSR.addParameter(func,5,_RowNum_)
	retval=PythonOSR.addParameter(func,6,_Vals_)
	retval=PythonOSR.addParameter(func,7,_TableName2_)
	retval=PythonOSR.addParameter(func,8,_ColName2_)
	retval=PythonOSR.addParameter(func,9,_RowNum2_)
	retval=PythonOSR.addParameter(func,10,_Vals2_)
	retval=PythonOSR.addParameter(func,11,_TableName3_)
	retval=PythonOSR.addParameter(func,12,_ColName3_)
	retval=PythonOSR.addParameter(func,13,_RowNum3_)
	retval=PythonOSR.addParameter(func,14,_Vals3_)
	retval=PythonOSR.addParameter(func,15,_TableName4_)
	retval=PythonOSR.addParameter(func,16,_ColName4_)
	retval=PythonOSR.addParameter(func,17,_RowNum4_)
	retval=PythonOSR.addParameter(func,18,_Vals4_)
	return PythonOSR.makeFunctionCall(func)


def SaveObjs(Handles=None,ObjectTypes=None,FileName=None,_Append_=None):
	"""Saves object to a file.

	Args:
		Handles: Handles to save to file
		ObjectTypes: Types of the objects. Single value or a vector with same lengths as Handles
		FileName: Name of the file to save to.
		_Append_: Optional. A number. If =1 then objects are appended to the file if it already exists.. Defaults to 0.

	"""
	func=PythonOSR.newFunction('SaveObjs',4)
	retval=PythonOSR.addParameter(func,0,Handles)
	retval=PythonOSR.addParameter(func,1,ObjectTypes)
	retval=PythonOSR.addParameter(func,2,FileName)
	retval=PythonOSR.addParameter(func,3,_Append_)
	return PythonOSR.makeFunctionCall(func)


def LoadObjsFromDataDirectory(DataDirectory=None):
	"""Sets and loads objects in the data directory.

	Args:
		DataDirectory: The data directory

	"""
	func=PythonOSR.newFunction('LoadObjsFromDataDirectory',1)
	retval=PythonOSR.addParameter(func,0,DataDirectory)
	return PythonOSR.makeFunctionCall(func)


def SurvFrac(MortHandle=None,_Age_=None,_Cause_=None):
	"""Returns the survival fraction for the supplied age.

	Args:
		MortHandle: The mort handle
		_Age_: Optional. The age. If not specified returns all nodes nodes, survival fraction and years lived used to build the curve.
		_Cause_: Optional. A comma-separated list of cause-of-death codes

	"""
	func=PythonOSR.newFunction('SurvFrac',3)
	retval=PythonOSR.addParameter(func,0,MortHandle)
	retval=PythonOSR.addParameter(func,1,_Age_)
	retval=PythonOSR.addParameter(func,2,_Cause_)
	return PythonOSR.makeFunctionCall(func)


def DeathRate(MortHandle=None,Age=None,_AgeInterval_=None,_Cause_=None):
	"""Returns death rate for age interval [Age,Age+AgeInterval).

	Args:
		MortHandle: The mort handle
		Age: The age.
		_AgeInterval_: Optional. The age interval. If not specified it defaults to 1.0
		_Cause_: Optional. A comma-separated list of cause-of-death codes

	"""
	func=PythonOSR.newFunction('DeathRate',4)
	retval=PythonOSR.addParameter(func,0,MortHandle)
	retval=PythonOSR.addParameter(func,1,Age)
	retval=PythonOSR.addParameter(func,2,_AgeInterval_)
	retval=PythonOSR.addParameter(func,3,_Cause_)
	return PythonOSR.makeFunctionCall(func)


def Deaths(MortHandle=None,Age=None,_AgeInterval_=None,_Cause_=None):
	"""Returns number of deaths in age interval [Age,Age+AgeInterval).

	Args:
		MortHandle: The mort handle
		Age: The age.
		_AgeInterval_: Optional. The age interval. If not specified it defaults to 1.0
		_Cause_: Optional. A comma-separated list of cause-of-death codes

	"""
	func=PythonOSR.newFunction('Deaths',4)
	retval=PythonOSR.addParameter(func,0,MortHandle)
	retval=PythonOSR.addParameter(func,1,Age)
	retval=PythonOSR.addParameter(func,2,_AgeInterval_)
	retval=PythonOSR.addParameter(func,3,_Cause_)
	return PythonOSR.makeFunctionCall(func)


def DeathProb(MortHandle=None,Age=None,_AgeInterval_=None,_Cause_=None):
	"""Returns the death probability for age interval [Age,Age+AgeInterval).

	Args:
		MortHandle: The mort handle
		Age: The age.
		_AgeInterval_: Optional. The age interval. If not specified it defaults to 1.0
		_Cause_: Optional. A comma-separated list of cause-of-death codes

	"""
	func=PythonOSR.newFunction('DeathProb',4)
	retval=PythonOSR.addParameter(func,0,MortHandle)
	retval=PythonOSR.addParameter(func,1,Age)
	retval=PythonOSR.addParameter(func,2,_AgeInterval_)
	retval=PythonOSR.addParameter(func,3,_Cause_)
	return PythonOSR.makeFunctionCall(func)


def SurvProb(MortHandle=None,Age=None,_AgeInterval_=None):
	"""Returns the survival probability for age interval [Age,Age+AgeInterval).

	Args:
		MortHandle: The mort handle
		Age: The age.
		_AgeInterval_: Optional. The age interval. If not specified it defaults to 1.0

	"""
	func=PythonOSR.newFunction('SurvProb',3)
	retval=PythonOSR.addParameter(func,0,MortHandle)
	retval=PythonOSR.addParameter(func,1,Age)
	retval=PythonOSR.addParameter(func,2,_AgeInterval_)
	return PythonOSR.makeFunctionCall(func)


def YearsLived(MortHandle=None,Age=None,_AgeInterval_=None):
	"""Returns the person-years lived for age interval [Age,Age+AgeInterval).

	Args:
		MortHandle: The mort handle
		Age: The age.
		_AgeInterval_: Optional. The age interval. If not specified it defaults to 1.0

	"""
	func=PythonOSR.newFunction('YearsLived',3)
	retval=PythonOSR.addParameter(func,0,MortHandle)
	retval=PythonOSR.addParameter(func,1,Age)
	retval=PythonOSR.addParameter(func,2,_AgeInterval_)
	return PythonOSR.makeFunctionCall(func)


def YearsLivedAfter(MortHandle=None,Age=None):
	"""Returns the person-years lived above Age.

	Args:
		MortHandle: The mort handle
		Age: The age.

	"""
	func=PythonOSR.newFunction('YearsLivedAfter',2)
	retval=PythonOSR.addParameter(func,0,MortHandle)
	retval=PythonOSR.addParameter(func,1,Age)
	return PythonOSR.makeFunctionCall(func)


def LifeExp(MortHandle=None,_Age_=None):
	"""Returns the expectation of life at Age.

	Args:
		MortHandle: The mort handle
		_Age_: Optional. The age. If not specified it defaults to 0.

	"""
	func=PythonOSR.newFunction('LifeExp',2)
	retval=PythonOSR.addParameter(func,0,MortHandle)
	retval=PythonOSR.addParameter(func,1,_Age_)
	return PythonOSR.makeFunctionCall(func)


def GetMortParams(MortHandle=None):
	"""Returns the buildmethod parameters

	Args:
		MortHandle: The mortality handle

	"""
	func=PythonOSR.newFunction('GetMortParams',1)
	retval=PythonOSR.addParameter(func,0,MortHandle)
	return PythonOSR.makeFunctionCall(func)


def DeathDist(MortHandle=None,Age=None,_Cause_=None):
	"""Returns the cumulative distribution function of death for the supplied age.

	Args:
		MortHandle: The mort handle
		Age: The age.
		_Cause_: Optional. A comma-separated list of cause-of-death codes for cause-specific death distribution

	"""
	func=PythonOSR.newFunction('DeathDist',3)
	retval=PythonOSR.addParameter(func,0,MortHandle)
	retval=PythonOSR.addParameter(func,1,Age)
	retval=PythonOSR.addParameter(func,2,_Cause_)
	return PythonOSR.makeFunctionCall(func)


def DyingProb(MortHandle=None,Cause=None,Age=None):
	"""Returns the eventually dying of a specified cause given alive at a given age.

	Args:
		MortHandle: The mort handle
		Cause: A comma-separated list of cause-of-death codes
		Age: The age.

	"""
	func=PythonOSR.newFunction('DyingProb',3)
	retval=PythonOSR.addParameter(func,0,MortHandle)
	retval=PythonOSR.addParameter(func,1,Cause)
	retval=PythonOSR.addParameter(func,2,Age)
	return PythonOSR.makeFunctionCall(func)


def SDSurvFrac(MortHandle=None,Cause=None,Age=None):
	"""Returns the single-decrement survival fraction.

	Args:
		MortHandle: The mort handle
		Cause: A comma-separated list of cause-of-death codes
		Age: The age.

	"""
	func=PythonOSR.newFunction('SDSurvFrac',3)
	retval=PythonOSR.addParameter(func,0,MortHandle)
	retval=PythonOSR.addParameter(func,1,Cause)
	retval=PythonOSR.addParameter(func,2,Age)
	return PythonOSR.makeFunctionCall(func)


def SDYearsLived(MortHandle=None,Cause=None,Age=None,_AgeInterval_=None):
	"""Returns the single-decrement person-years lived for age interval [Age,Age+AgeInterval).

	Args:
		MortHandle: The mort handle
		Cause: A comma-separated list of cause-of-death codes
		Age: The age.
		_AgeInterval_: Optional. The age interval. If not specified it defaults to 1.0

	"""
	func=PythonOSR.newFunction('SDYearsLived',4)
	retval=PythonOSR.addParameter(func,0,MortHandle)
	retval=PythonOSR.addParameter(func,1,Cause)
	retval=PythonOSR.addParameter(func,2,Age)
	retval=PythonOSR.addParameter(func,3,_AgeInterval_)
	return PythonOSR.makeFunctionCall(func)


def SDYearsLivedAfter(MortHandle=None,Cause=None,Age=None):
	"""Returns the single-decrement person-years lived above Age.

	Args:
		MortHandle: The mort handle
		Cause: A comma-separated list of cause-of-death codes
		Age: The age.

	"""
	func=PythonOSR.newFunction('SDYearsLivedAfter',3)
	retval=PythonOSR.addParameter(func,0,MortHandle)
	retval=PythonOSR.addParameter(func,1,Cause)
	retval=PythonOSR.addParameter(func,2,Age)
	return PythonOSR.makeFunctionCall(func)


def CreateScenarioMort(NewMortHandle=None,MortHandle=None,ScenarioHandle=None):
	"""Creates a mortaliy object by applying a scenario to an existing mortality

	Args:
		NewMortHandle: The new mort handle
		MortHandle: The existing handle
		ScenarioHandle: A results object specifying the scenario

	"""
	func=PythonOSR.newFunction('CreateScenarioMort',3)
	retval=PythonOSR.addParameter(func,0,NewMortHandle)
	retval=PythonOSR.addParameter(func,1,MortHandle)
	retval=PythonOSR.addParameter(func,2,ScenarioHandle)
	return PythonOSR.makeFunctionCall(func)


def OutSurvival(MortHandle1=None,MortHandle2=None,_Age_=None,_Omega_=None):
	"""Returns the probability MortHandle1 outsurvives  MortHandle2 given both alive at Age.

	Args:
		MortHandle1: The first mort handle
		MortHandle2: The second mort handle
		_Age_: Optional. The age. If not specified it defaults to 0.
		_Omega_: Optional. Controls upper bound of numerical integral. Defaults to 120.

	"""
	func=PythonOSR.newFunction('OutSurvival',4)
	retval=PythonOSR.addParameter(func,0,MortHandle1)
	retval=PythonOSR.addParameter(func,1,MortHandle2)
	retval=PythonOSR.addParameter(func,2,_Age_)
	retval=PythonOSR.addParameter(func,3,_Omega_)
	return PythonOSR.makeFunctionCall(func)


def ModalDeathAge(MortHandle=None,_AgeLo_=None,_AgeHi_=None,_Tol_=None):
	"""Returns the modal age at death probability MortHandle1 outsurvives  MortHandle2 given both alive at Age.

	Args:
		MortHandle: The mort handle
		_AgeLo_: Optional. The age lower bound. If not specified it defaults to 15.
		_AgeHi_: Optional. The age upper bound. If not specified it defaults to 110.
		_Tol_: Optional. The tolerance. If not specified it defaults to 0.0001.

	"""
	func=PythonOSR.newFunction('ModalDeathAge',4)
	retval=PythonOSR.addParameter(func,0,MortHandle)
	retval=PythonOSR.addParameter(func,1,_AgeLo_)
	retval=PythonOSR.addParameter(func,2,_AgeHi_)
	retval=PythonOSR.addParameter(func,3,_Tol_)
	return PythonOSR.makeFunctionCall(func)


def LifeDisp(MortHandle=None,_Age_=None,_Epsilon_=None):
	"""Returns the life disparity at Age.

	Args:
		MortHandle: The mort handle
		_Age_: Optional. The age. If not specified it defaults to 0.
		_Epsilon_: Optional. Controls local accuracy of numerical integral. Defaults to 1.0e-6

	"""
	func=PythonOSR.newFunction('LifeDisp',3)
	retval=PythonOSR.addParameter(func,0,MortHandle)
	retval=PythonOSR.addParameter(func,1,_Age_)
	retval=PythonOSR.addParameter(func,2,_Epsilon_)
	return PythonOSR.makeFunctionCall(func)


def FertRate(FertHandle=None,Age=None,_AgeInterval_=None):
	"""Returns the age-specific fertility rate for age interval [Age,Age+AgeInterval).

	Args:
		FertHandle: The fertility handle
		Age: The age.
		_AgeInterval_: Optional. The age interval. If not specified it defaults to 1.0

	"""
	func=PythonOSR.newFunction('FertRate',3)
	retval=PythonOSR.addParameter(func,0,FertHandle)
	retval=PythonOSR.addParameter(func,1,Age)
	retval=PythonOSR.addParameter(func,2,_AgeInterval_)
	return PythonOSR.makeFunctionCall(func)


def TotalFertRate(FertHandle=None):
	"""Returns the total (period) fertility rate.

	Args:
		FertHandle: The fertility handle

	"""
	func=PythonOSR.newFunction('TotalFertRate',1)
	retval=PythonOSR.addParameter(func,0,FertHandle)
	return PythonOSR.makeFunctionCall(func)


def GetFertParams(FertHandle=None):
	"""Returns the buildmethod parameters

	Args:
		FertHandle: The fertility handle

	"""
	func=PythonOSR.newFunction('GetFertParams',1)
	retval=PythonOSR.addParameter(func,0,FertHandle)
	return PythonOSR.makeFunctionCall(func)


def NetReproRate(FertHandle=None,MortHandle=None,_SexRatio_=None,_Epsilon_=None):
	"""Returns the Net Reproduction Rate

	Args:
		FertHandle: The fertility handle
		MortHandle: The female mortality handle
		_SexRatio_: Optional. The sex ratio. Defaults to 1.05
		_Epsilon_: Optional. Controls local accuracy of numerical integral. Defaults to 1.0e-6

	"""
	func=PythonOSR.newFunction('NetReproRate',4)
	retval=PythonOSR.addParameter(func,0,FertHandle)
	retval=PythonOSR.addParameter(func,1,MortHandle)
	retval=PythonOSR.addParameter(func,2,_SexRatio_)
	retval=PythonOSR.addParameter(func,3,_Epsilon_)
	return PythonOSR.makeFunctionCall(func)


def Births(FertHandle=None,PCurveHandle=None,_Epsilon_=None):
	"""Returns the number of biths per annum

	Args:
		FertHandle: The fertility handle
		PCurveHandle: The pcurve handle
		_Epsilon_: Optional. Controls local accuracy of numerical integral. Defaults to 1.0e-6

	"""
	func=PythonOSR.newFunction('Births',3)
	retval=PythonOSR.addParameter(func,0,FertHandle)
	retval=PythonOSR.addParameter(func,1,PCurveHandle)
	retval=PythonOSR.addParameter(func,2,_Epsilon_)
	return PythonOSR.makeFunctionCall(func)


def MeanAgeChild(FertHandle=None,_Epsilon_=None):
	"""Returns the Mean Age at Childbearing

	Args:
		FertHandle: The fertility handle
		_Epsilon_: Optional. Controls local accuracy of numerical integral. Defaults to 1.0e-6

	"""
	func=PythonOSR.newFunction('MeanAgeChild',2)
	retval=PythonOSR.addParameter(func,0,FertHandle)
	retval=PythonOSR.addParameter(func,1,_Epsilon_)
	return PythonOSR.makeFunctionCall(func)


def Number(PCurveHandle=None,Age=None,_AgeInterval_=None):
	"""Returns the population number for age interval [Age,Age+AgeInterval).

	Args:
		PCurveHandle: The PCurve handle
		Age: The age.
		_AgeInterval_: Optional. The age interval. If not specified it defaults to 1.0

	"""
	func=PythonOSR.newFunction('Number',3)
	retval=PythonOSR.addParameter(func,0,PCurveHandle)
	retval=PythonOSR.addParameter(func,1,Age)
	retval=PythonOSR.addParameter(func,2,_AgeInterval_)
	return PythonOSR.makeFunctionCall(func)


def TotalNumber(PCurveHandle=None):
	"""Returns the total number in a population.

	Args:
		PCurveHandle: The PCurve handle

	"""
	func=PythonOSR.newFunction('TotalNumber',1)
	retval=PythonOSR.addParameter(func,0,PCurveHandle)
	return PythonOSR.makeFunctionCall(func)


def GetPCurveParams(PCurveHandle=None):
	"""Returns the buildmethod parameters

	Args:
		PCurveHandle: The pcurve handle

	"""
	func=PythonOSR.newFunction('GetPCurveParams',1)
	retval=PythonOSR.addParameter(func,0,PCurveHandle)
	return PythonOSR.makeFunctionCall(func)


def MedianAge(PCurveHandle=None,_Age_=None):
	"""Returns the median age for the population with the age greater than or equal to Age.

	Args:
		PCurveHandle: The PCurve handle
		_Age_: Optional. The minimum age. If not specified it defaults to 0.0

	"""
	func=PythonOSR.newFunction('MedianAge',2)
	retval=PythonOSR.addParameter(func,0,PCurveHandle)
	retval=PythonOSR.addParameter(func,1,_Age_)
	return PythonOSR.makeFunctionCall(func)


def MigrationProb(MigrationHandle=None,Age=None,_AgeInterval_=None,_ToPop_=None):
	"""Returns the migration probability for age interval [Age,Age+AgeInterval).

	Args:
		MigrationHandle: The migration handle
		Age: The age.
		_AgeInterval_: Optional. The age interval. If not specified it defaults to 1.0
		_ToPop_: Optional. A comma-separated list of destination population codes

	"""
	func=PythonOSR.newFunction('MigrationProb',4)
	retval=PythonOSR.addParameter(func,0,MigrationHandle)
	retval=PythonOSR.addParameter(func,1,Age)
	retval=PythonOSR.addParameter(func,2,_AgeInterval_)
	retval=PythonOSR.addParameter(func,3,_ToPop_)
	return PythonOSR.makeFunctionCall(func)


def GetMigrationParams(MigrationHandle=None):
	"""Returns the buildmethod parameters

	Args:
		MigrationHandle: The migration handle

	"""
	func=PythonOSR.newFunction('GetMigrationParams',1)
	retval=PythonOSR.addParameter(func,0,MigrationHandle)
	return PythonOSR.makeFunctionCall(func)


def MigrationRatio(MigrationHandle=None,Age=None,_AgeInterval_=None,ToPop=None):
	"""Returns the migration ratio for age interval [Age,Age+AgeInterval) and destination ToPop.

	Args:
		MigrationHandle: The migration handle
		Age: The age.
		_AgeInterval_: Optional. The age interval. If not specified it defaults to 1.0
		ToPop: A comma-separated list of destination population codes

	"""
	func=PythonOSR.newFunction('MigrationRatio',4)
	retval=PythonOSR.addParameter(func,0,MigrationHandle)
	retval=PythonOSR.addParameter(func,1,Age)
	retval=PythonOSR.addParameter(func,2,_AgeInterval_)
	retval=PythonOSR.addParameter(func,3,ToPop)
	return PythonOSR.makeFunctionCall(func)


def CalibReturnMigration(ReturnHandle=None,OneYearHandle=None,MultiYearHandle=None,_ExtraInfo_=None):
	"""Calibrates a return migration object implied by OneYearHandle and MultiYearHandle.

	Args:
		ReturnHandle: The object to calibrate
		OneYearHandle: The one year migration object.
		MultiYearHandle: The multi-year migration object.
		_ExtraInfo_: Optional. ExtraInfo string specifying calibration options. Defaults to the empty string

	"""
	func=PythonOSR.newFunction('CalibReturnMigration',4)
	retval=PythonOSR.addParameter(func,0,ReturnHandle)
	retval=PythonOSR.addParameter(func,1,OneYearHandle)
	retval=PythonOSR.addParameter(func,2,MultiYearHandle)
	retval=PythonOSR.addParameter(func,3,_ExtraInfo_)
	return PythonOSR.makeFunctionCall(func)


def MultiYearMigrationProb(OneYearHandle=None,ReturnHandle=None,Age=None,_AgeInterval_=None):
	"""Returns the multi-year migration probability for age interval [Age,Age+AgeInterval) accounting for return migration.

	Args:
		OneYearHandle: The out migration handle
		ReturnHandle: The return migration handle
		Age: The age.
		_AgeInterval_: Optional. The age interval. If not specified it defaults to 1.0

	"""
	func=PythonOSR.newFunction('MultiYearMigrationProb',4)
	retval=PythonOSR.addParameter(func,0,OneYearHandle)
	retval=PythonOSR.addParameter(func,1,ReturnHandle)
	retval=PythonOSR.addParameter(func,2,Age)
	retval=PythonOSR.addParameter(func,3,_AgeInterval_)
	return PythonOSR.makeFunctionCall(func)


def CreateOneYearMig(OneYearHandle=None,MultiYearHandle=None,ReturnHandle=None,_ExtraInfo_=None):
	"""Creates a one-year migration object implied by MultiYearHandle and ReturnHandle.

	Args:
		OneYearHandle: The object to create
		MultiYearHandle: The multi-year migration object.
		ReturnHandle: The return migration object.
		_ExtraInfo_: Optional. ExtraInfo string specifying options. Defaults to the empty string

	"""
	func=PythonOSR.newFunction('CreateOneYearMig',4)
	retval=PythonOSR.addParameter(func,0,OneYearHandle)
	retval=PythonOSR.addParameter(func,1,MultiYearHandle)
	retval=PythonOSR.addParameter(func,2,ReturnHandle)
	retval=PythonOSR.addParameter(func,3,_ExtraInfo_)
	return PythonOSR.makeFunctionCall(func)


def GroupedProb(MigrationHandle=None,_PCurveHandle_=None,Age=None,_AgeInterval_=None,_GroupInterval_=None,_ToPop_=None):
	"""Returns the grouped migration probability for age group [Age,Age+GroupInterval) over interval AgeInterval.

	Args:
		MigrationHandle: The migration handle
		_PCurveHandle_: Optional. The pcurve handle specifying the weights in the group average. If not specified weights are constant.
		Age: The age.
		_AgeInterval_: Optional. The age interval. If not specified it defaults to 1.0
		_GroupInterval_: Optional. The age group width. If not specified it defaults to 1.0
		_ToPop_: Optional. A comma-separated list of destination population codes

	"""
	func=PythonOSR.newFunction('GroupedProb',6)
	retval=PythonOSR.addParameter(func,0,MigrationHandle)
	retval=PythonOSR.addParameter(func,1,_PCurveHandle_)
	retval=PythonOSR.addParameter(func,2,Age)
	retval=PythonOSR.addParameter(func,3,_AgeInterval_)
	retval=PythonOSR.addParameter(func,4,_GroupInterval_)
	retval=PythonOSR.addParameter(func,5,_ToPop_)
	return PythonOSR.makeFunctionCall(func)


def GroupedRatio(MigrationHandle=None,_PCurveHandle_=None,Age=None,_AgeInterval_=None,_GroupInterval_=None,ToPop=None):
	"""Returns the grouped migration ratio for age group [Age,Age+GroupInterval) over interval AgeInterval for destination ToPop.

	Args:
		MigrationHandle: The migration handle
		_PCurveHandle_: Optional. The pcurve handle specifying the weights in the group average. If not specified weights are constant.
		Age: The age.
		_AgeInterval_: Optional. The age interval. If not specified it defaults to 1.0
		_GroupInterval_: Optional. The age group width. If not specified it defaults to 1.0
		ToPop: A comma-separated list of destination population codes

	"""
	func=PythonOSR.newFunction('GroupedRatio',6)
	retval=PythonOSR.addParameter(func,0,MigrationHandle)
	retval=PythonOSR.addParameter(func,1,_PCurveHandle_)
	retval=PythonOSR.addParameter(func,2,Age)
	retval=PythonOSR.addParameter(func,3,_AgeInterval_)
	retval=PythonOSR.addParameter(func,4,_GroupInterval_)
	retval=PythonOSR.addParameter(func,5,ToPop)
	return PythonOSR.makeFunctionCall(func)




# Functions used on import

# def _Osier_onImport():

	# root = os.path.dirname(os.path.realpath(__file__))
	
	# ConfigFile=os.path.normpath(os.path.join(root,'..','PythonOSR.cfg'))
	
	# #Set configuration variables
	# cfgdata=_Osier_SetFromConfigFile(ConfigFile)
		

	# #Load osier library
	# try:
		# Osier.LoadLibrary()
		# if Osier.ErrorFlag():
			# print Osier.GetError()
	# except OSError:
		# errmsg='Problem loading Osier shared library.\n'
		# errmsg+='Have you set the correct paths in '+ConfigFile+'?\n'
		# print(errmsg)
		# raise
		
	# #Load objects from data dir
	# try: 
		# Osier.LoadObjsFromDataDirectory(cfgdata['DATADIRECTORY'])
		# if Osier.ErrorFlag():
			# print(Osier.GetError())
	# except OSError:
		# errmsg='Problem loading objects from data directory.\n'
		# errmsg+='Have you set the correct paths in '+ConfigFile+'?\n'
		# print(errmsg)
		# raise

# _Osier_onImport()