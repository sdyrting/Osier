import pythonosr.osr as osr
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
import numpy as np

#
# MultiMort
#

print("\nMultiMort\n=========\n")
DRMultiMort = osr.CreateObj(
  Handle = "USD-W-M_ASDR_1970",
  ObjectType = "MORTALITY",
  BodyProps = ["Population","Date","BuildMethod","MultiDecBuildMethod"],
  BodyValues = ["USA-W-M",19700630,'CALIBRATED_SPLINE:"P=1000000"',"HYBRID_RATIO"],
  _TableName_ = "DeathRates",
  _TableCols_ = ["Age","Rate"],
  _TableValues_ = [
    [0,	0.02113239],
    [1,	0.000836017],
    [5,	0.000474801],
    [10,	0.000485071],
    [15,	0.001471427],
    [20,	0.001989967],
    [25,	0.001691855],
    [30,	0.001853781],
    [35,	0.002604102],
    [40,	0.004200407],
    [45,	0.006845684],
    [50,	0.010986321],
    [55,	0.017746092],
    [60,	0.027083745],
    [65,	0.040461201],
    [70,	0.058280413],
    [75,	0.086934172],
    [80,	0.126068196],
    [85,	0.185517407]],
  _TableName2_ = "DeathRatios",
  _TableCols2_ = ["Age","CAN","CIR","ACC","OTH"],
  _TableValues2_ = [
    [0,	65,	267,	935,	30458],
    [1,	501,	163,	2119,	2127],
    [5,	708,	134,	2119,	1138],
    [10,	526,	163,	2708,	985],
    [15,	742,	319,	9628,	1511],
    [20,	867,	443,	10834,	1668],
    [25,	800,	595,	7051,	1451],
    [30,	941,	1202,	5246,	1741],
    [35,	1608,	3104,	5059,	2688],
    [40,	3392,	7848,	5608,	4971],
    [45,	6463,	15817,	5955,	7757],
    [50,	10893,	25843,	5782,	10574],
    [55,	17133,	38853,	5791,	14725],
    [60,	22505,	52365,	5145,	18766],
    [65,	24691,	63340,	4404,	21179],
    [70,	24317,	72177,	3890,	22445],
    [75,	21468,	77556,	3495,	22460],
    [80,	14260,	67265,	2746,	17285],
    [85,	8630,	63998,	2469,	15242]]
)
print(DRMultiMort)

SFMultiMort = osr.CreateObj(
  Handle = "USD-W-M_SF_1970",
  ObjectType = "MORTALITY",
  BodyProps = ["Population","Date","BuildMethod","MultiDecBuildMethod"],
  BodyValues = ["USA-W-M",19700630,"HELIGMAN_POLLARD8","HYBRID_RATIO"],
  _TableName_ = "SurvivalFractions",
  _TableCols_ = ["Age","SurvivalFraction"],
  _TableValues_ = [
    [0,	1],
    [1,	0.979156079],
    [5,	0.975888266],
    [10,	0.973574439],
    [15,	0.971215554],
    [20,	0.964094161],
    [25,	0.954548712],
    [30,	0.946508207],
    [35,	0.937773994],
    [40,	0.925636956],
    [45,	0.906382596],
    [50,	0.875841109],
    [55,	0.828923886],
    [60,	0.75831596],
    [65,	0.661850891],
    [70,	0.539918456],
    [75,	0.402299856],
    [80,	0.258883527],
    [85,	0.136293612]],
  _TableName2_ = "DeathRatios",
  _TableCols2_ = ["Age","CAN","CIR","ACC","OTH"],
  _TableValues2_ = [
    [0,	65,	267,	935,	30458],
    [1,	501,	163,	2119,	2127],
    [5,	708,	134,	2119,	1138],
    [10,	526,	163,	2708,	985],
    [15,	742,	319,	9628,	1511],
    [20,	867,	443,	10834,	1668],
    [25,	800,	595,	7051,	1451],
    [30,	941,	1202,	5246,	1741],
    [35,	1608,	3104,	5059,	2688],
    [40,	3392,	7848,	5608,	4971],
    [45,	6463,	15817,	5955,	7757],
    [50,	10893,	25843,	5782,	10574],
    [55,	17133,	38853,	5791,	14725],
    [60,	22505,	52365,	5145,	18766],
    [65,	24691,	63340,	4404,	21179],
    [70,	24317,	72177,	3890,	22445],
    [75,	21468,	77556,	3495,	22460],
    [80,	14260,	67265,	2746,	17285],
    [85,	8630,	63998,	2469,	15242]]
)
print(SFMultiMort)

MultiMort = DRMultiMort

#
# DeathRate
#

print("\nDeathRate\n=========\n")

mmort_data = pd.DataFrame({'Age': np.arange(0,111)}).merge(
    pd.DataFrame({'CauseCode': ["CAN,CIR,ACC,OTH","CAN","CIR","ACC","OTH"],
                  'Cause': ['Total','CAN','CIR','ACC','OTH']}),how='cross')
mmort_data['CSDR']=mmort_data.apply(lambda x: osr.DeathRate(MultiMort,x.Age,None,x.CauseCode),axis=1)
sns.lineplot(data=mmort_data,x='Age',y='CSDR',hue='Cause')
plt.ylabel('DeathRate')
plt.yscale('log')
plt.show()
input('Press Enter to continue to next plot ...')
plt.close()


#
# DeathProb
#

print("\nDeathProb\n=========\n")
AgeInterval = 5

mmort_data['CSDP']=mmort_data.apply(lambda x: osr.DeathProb(MultiMort,x.Age,AgeInterval,x.CauseCode),axis=1)
sns.lineplot(data=mmort_data,x='Age',y='CSDP',hue='Cause')
plt.ylabel('DeathProb')
plt.yscale('log')
plt.show()
input('Press Enter to continue to next plot ...')
plt.close()


#
# Deaths
#

print("\nDeaths\n======\n")

mmort_data['CSD']=mmort_data.apply(lambda x: osr.Deaths(MultiMort,x.Age,AgeInterval,x.CauseCode),axis=1)
sns.lineplot(data=mmort_data,x='Age',y='CSD',hue='Cause')
plt.ylabel('Deaths')
plt.show()
input('Press Enter to continue to next plot ...')
plt.close()

#
# SurvFrac
#

print("\nSurvFrac\n========\n")

mmort_data['CSSF']=mmort_data.apply(lambda x: osr.SurvFrac(MultiMort,x.Age,x.CauseCode),axis=1)
sns.lineplot(data=mmort_data,x='Age',y='CSSF',hue='Cause')
plt.ylabel('SurvFrac')
plt.show()
input('Press Enter to continue to next plot ...')
plt.close()

#
# DeathDist
#

print("\nDeathDist\n=========\n")

mmort_data['CSDD']=mmort_data.apply(lambda x: osr.DeathDist(MultiMort,x.Age,x.CauseCode),axis=1)
sns.lineplot(data=mmort_data,x='Age',y='CSDD',hue='Cause')
plt.ylabel('DeathDist')
plt.show()
input('Press Enter to continue to next plot ...')
plt.close()

#
# DyingProb
#

print("\nDyingProb\n==========\n")

mmort_data['CSDyP']=mmort_data.apply(lambda x: osr.DyingProb(MultiMort,x.CauseCode,x.Age),axis=1)
sns.lineplot(data=mmort_data.query('Cause != "Total"'),x='Age',y='CSDyP',hue='Cause')
plt.ylabel('DyingProb')
plt.show()
input('Press Enter to continue to next plot ...')
plt.close()

#
# SDSurvFrac
#

print("\nSDSurvFrac\n==========\n")

mmort_data['SDSF']=mmort_data.apply(lambda x: osr.SDSurvFrac(MultiMort,x.CauseCode,x.Age),axis=1)
sns.lineplot(data=mmort_data.query('Cause != "Total"'),x='Age',y='SDSF',hue='Cause')
plt.ylabel('SDSurvFrac')
plt.show()
input('Press Enter to continue to next plot ...')
plt.close()

#
# SDYearsLived
#

print("\nSDYearsLived\n============\n")

mmort_data['SDYL']=mmort_data.apply(lambda x: osr.SDYearsLived(MultiMort,x.CauseCode,x.Age),axis=1)
sns.lineplot(data=mmort_data.query('Cause != "Total"'),x='Age',y='SDYL',hue='Cause')
plt.ylabel('SDYearsLived')
plt.show()
input('Press Enter to continue to next plot ...')
plt.close()

#
# SDYearsLivedAfter
#

print("\nSDYearsLivedAfter\n=================\n")

mmort_data['SDYLA']=mmort_data.apply(lambda x: osr.SDYearsLivedAfter(MultiMort,x.CauseCode,x.Age),axis=1)
sns.lineplot(data=mmort_data.query('Cause != "Total"'),x='Age',y='SDYLA',hue='Cause')
plt.ylabel('SDYearsLivedAfter')
plt.show()
input('Press Enter to continue to next plot ...')
plt.close()

#
# CreateScenarioMort
#

print("\nCreateScenarioMort\n==================\n")
NoCANSc = osr.CreateObj(
  Handle = "NoCAN",
  ObjectType = "RESULTS",
  BodyProps = ["Scenario","Cause"],
  BodyValues = ["MULTIDEC","~CAN"]
)

NoCANMort = osr.CreateScenarioMort(
  NewMortHandle = "NoCANMort",
  MortHandle = MultiMort,
  ScenarioHandle = NoCANSc)
print(NoCANMort)

print('LifeExp(AllCause)='+str(osr.LifeExp(MultiMort)))
print("LifeExp(NoCAN)="+str(osr.LifeExp(NoCANMort)))