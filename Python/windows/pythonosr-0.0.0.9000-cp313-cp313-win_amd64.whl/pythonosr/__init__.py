import os
import sys
#import ctypes

def _pythonosr_readconf(configfile,sep,com) :
 
	R={}
	with open(configfile,'rt') as f:
		for line in f:
			line=line.strip()
			if ((line == '') or line.isspace() or (line[0] == com)) :
				pass # no operation 
			else: 
				cstr = line.split(sep)
				var=cstr[0].upper()
				tok=cstr[1]
				R[var] = tok
	
	return R

def _pythonosr_SetFromConfigFile(ConfigFile):
	cfgdata=_pythonosr_readconf(ConfigFile,'=','#')

	if 'DATADIRECTORY' not in cfgdata:
		cfgdata['DATADIRECTORY']=''

	if 'WLOXDIRECTORY' not in cfgdata:
		cfgdata['WLOXDIRECTORY']=''
	
	if 'OSIERDIRECTORY' not in cfgdata:
		cfgdata['OSIERDIRECTORY']=cfgdata['WLOXDIRECTORY']
	
	if 'PYTHONOSRDIRECTORY' not in cfgdata:
		cfgdata['PYTHONOSRDIRECTORY']=cfgdata['WLOXDIRECTORY']

	return cfgdata

def _pythonosr_init():
	root = os.path.dirname(os.path.realpath(__file__))
	
    # Define flags for different compilers
	if sys.platform == "win32":
		config_file_name='PythonOSR.cfg'  # Windows
	else:
		config_file_name='PythonOSR_unix.cfg'  # Not-Windows

	ConfigFile=os.path.normpath(os.path.join(root,config_file_name))
	
	#Set configuration variables
	cfgdata=_pythonosr_SetFromConfigFile(ConfigFile)
			
	#import PythonOSR
	try:
		import PythonOSR
	except ModuleNotFoundError:
		errmsg='Problem finding module PythonOSR.\n'
		errmsg+='Have you set the correct paths in '+ConfigFile+'?\n'
		print(errmsg)
		raise
	
	# Load objs for datadir
	import pythonosr.osr as osr
	data_dir_path = os.path.normpath(os.path.join(root,cfgdata['DATADIRECTORY']))+'/'
	osr.LoadObjsFromDataDirectory(data_dir_path)
    
	return
    
_pythonosr_init()
