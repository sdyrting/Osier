import pandas
from importlib import resources

def load(name) :
    """Loads example dataset

    Args:
        name: the name of the dataset
		
    """
    file_name=resources.files('pythonosr').joinpath('data/'+name+'.csv')
    df=pandas.read_csv(file_name)
    return df

def get_names() :
    """Returns a list of available example dataset names"""
    data_dir=resources.files('pythonosr').joinpath('data')
    csv_files = data_dir.glob('*.csv')
    names=[]
    for csv_file in csv_files:
        names.append(csv_file.stem)
    return names

