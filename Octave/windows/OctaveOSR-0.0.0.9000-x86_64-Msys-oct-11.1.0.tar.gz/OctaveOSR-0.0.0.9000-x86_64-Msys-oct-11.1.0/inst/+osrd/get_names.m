function names=get_names()
	root = fileparts(mfilename ('fullpath'));
    data_dir=[root,'/../data'];
	csv_dir = dir([data_dir,'/*.csv']);
	csv_files = {csv_dir.name};
    names={};
    for csv_file = csv_files
        [fdir,fname,fext]=fileparts(csv_file{1});
		names{end+1}=fname;
	endfor
endfunction