function df = load_dataset(name)
	root = fileparts(mfilename ('fullpath'));
    file_name=[root,'/../data/',name,'.csv'];
    df=dataframe(file_name);
endfunction
