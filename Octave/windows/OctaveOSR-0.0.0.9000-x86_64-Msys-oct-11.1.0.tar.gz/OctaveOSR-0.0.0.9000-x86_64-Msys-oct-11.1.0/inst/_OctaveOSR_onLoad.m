## PKG_ADD: _OctaveOSR_onLoad()

function retval=_OctaveOSR_onLoad()
	root = fileparts (mfilename ('fullpath'));
    if (ispc())
        ConfigFile="OctaveOSR.cfg";
	else
        ConfigFile="OctaveOSR_unix.cfg";
    endif
    ConfigFile=fullfile(root,ConfigFile);
    
	%Set configuration variables
	cfgdata=_OctaveOSR_SetFromConfigFile(ConfigFile);
		
	%Add paths to shared libraries
	% addpath(cfgdata.OCTAVEOSRDIRECTORY); 
	% setenv("PATH",[getenv("PATH"),";",cfgdata.WLOXDIRECTORY,";",cfgdata.OSIERDIRECTORY]);
		
	%Load Osier library
	h=osr();
	% try
		% LoadLibrary(h);
		% if (ErrorFlag(h))
			% disp(GetError(h));
		% endif
	% catch err
		% disp(err.message);
		% disp(["Have you set the correct paths in ",ConfigFile,"?"]);
	% end_try_catch
	
	%Load objects from data dir
	try 
        data_dir_path = fullfile(root,cfgdata.DATADIRECTORY);
		LoadObjsFromDataDirectory(h,data_dir_path);
		if (ErrorFlag(h))
			disp(GetError(h));
		endif
	catch err
		disp(err.message);
		disp(["Have you set the correct paths in ",ConfigFile,"?"]);
	end_try_catch
	
endfunction

function R = _OctaveOSR_readconf(configfile,sep,com)
	fid = fopen(configfile); 
	if (fid<0)
		error('cannot open file %s\n',configfile); 
	end; 
 
	while (~feof(fid))
		line = strtrim(fgetl(fid));
		if (isempty(line) || all(isspace(line)) || strncmp(line,com,1))
			% no operation 
		else 
			cstr = strsplit(line,sep);
			var=upper(cstr{1});
			tok=strtrim(cstr{2});
			R.(var) = tok;		% return value of function
		endif;
	end; 
	fclose(fid);
endfunction

function cfgdata=_OctaveOSR_SetFromConfigFile(ConfigFile)
	cfgdata=_OctaveOSR_readconf(ConfigFile,'=','#');

	if (!isfield(cfgdata,"DATADIRECTORY"))
		cfgdata.DATADIRECTORY="";
	endif

	if (!isfield(cfgdata,"WLOXDIRECTORY"))
		cfgdata.WLOXDIRECTORY="";
	endif
	
	if (!isfield(cfgdata,"OSIERDIRECTORY"))
		cfgdata.OSIERDIRECTORY=cfgdata.WLOXDIRECTORY;
	endif
	
	if (!isfield(cfgdata,"OCTAVEOSRDIRECTORY"))
		cfgdata.OCTAVEOSRDIRECTORY=cfgdata.WLOXDIRECTORY;
	endif

endfunction


