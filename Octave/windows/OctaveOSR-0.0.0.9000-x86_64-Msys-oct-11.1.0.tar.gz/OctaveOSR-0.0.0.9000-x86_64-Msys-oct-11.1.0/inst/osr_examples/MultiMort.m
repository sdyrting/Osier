## Multi-Decrement Example
#
# This script illustrates how to use some of Osier's cause-specific mortality functions
##

pkg load octaveosr;

h=osr();

#
# MultiMort
#

disp("\nMultiMort\n=========\n")
Handle = "USD-W-M_ASDR_1970";
ObjectType = "MORTALITY";
BodyProps = {"Population","Date","BuildMethod","MultiDecBuildMethod"};
BodyValues = {"USA-W-M",19700630,'CALIBRATED_SPLINE:"P=1000000"',"HYBRID_RATIO"}';
TableName = "DeathRates";
TableCols = {"Age","Rate"};
TableValues = {...
    0,	0.02113239;...
    1,	0.000836017;...
    5,	0.000474801;...
    10,	0.000485071;...
    15,	0.001471427;...
    20,	0.001989967;...
    25,	0.001691855;...
    30,	0.001853781;...
    35,	0.002604102;...
    40,	0.004200407;...
    45,	0.006845684;...
    50,	0.010986321;...
    55,	0.017746092;...
    60,	0.027083745;...
    65,	0.040461201;...
    70,	0.058280413;...
    75,	0.086934172;...
    80,	0.126068196;...
    85,	0.185517407};
TableName2 = "DeathRatios";
TableCols2 = {"Age","CAN","CIR","ACC","OTH"};
TableValues2 = {...
    0,	65,	267,	935,	30458;...
    1,	501,	163,	2119,	2127;...
    5,	708,	134,	2119,	1138;...
    10,	526,	163,	2708,	985;...
    15,	742,	319,	9628,	1511;...
    20,	867,	443,	10834,	1668;...
    25,	800,	595,	7051,	1451;...
    30,	941,	1202,	5246,	1741;...
    35,	1608,	3104,	5059,	2688;...
    40,	3392,	7848,	5608,	4971;...
    45,	6463,	15817,	5955,	7757;...
    50,	10893,	25843,	5782,	10574;...
    55,	17133,	38853,	5791,	14725;...
    60,	22505,	52365,	5145,	18766;...
    65,	24691,	63340,	4404,	21179;...
    70,	24317,	72177,	3890,	22445;...
    75,	21468,	77556,	3495,	22460;...
    80,	14260,	67265,	2746,	17285;...
    85,	8630,	63998,	2469,	15242};

DRMultiMort = CreateObj(h,Handle,ObjectType,BodyProps,BodyValues,...
    TableName,TableCols,TableValues,TableName2,TableCols2,TableValues2);

disp(DRMultiMort);

Handle = "USD-W-M_SF_1970";
ObjectType = "MORTALITY";
BodyProps = {"Population","Date","BuildMethod","MultiDecBuildMethod"};
BodyValues = {"USA-W-M",19700630,"HELIGMAN_POLLARD8","HYBRID_RATIO"}';
TableName = "SurvivalFractions";
TableCols = {"Age","SurvivalFraction"};
TableValues = {...
    0,	1,
    1,	0.979156079;...
    5,	0.975888266;...
    10,	0.973574439;...
    15,	0.971215554;...
    20,	0.964094161;...
    25,	0.954548712;...
    30,	0.946508207;...
    35,	0.937773994;...
    40,	0.925636956;...
    45,	0.906382596;...
    50,	0.875841109;...
    55,	0.828923886;...
    60,	0.75831596;...
    65,	0.661850891;...
    70,	0.539918456;...
    75,	0.402299856;...
    80,	0.258883527;...
    85,	0.136293612};
TableName2 = "DeathRatios";
TableCols2 = {"Age","CAN","CIR","ACC","OTH"};
TableValues2 = {...
    0,	65,	267,	935,	30458;...
    1,	501,	163,	2119,	2127;...
    5,	708,	134,	2119,	1138;...
    10,	526,	163,	2708,	985;...
    15,	742,	319,	9628,	1511;...
    20,	867,	443,	10834,	1668;...
    25,	800,	595,	7051,	1451;...
    30,	941,	1202,	5246,	1741;...
    35,	1608,	3104,	5059,	2688;...
    40,	3392,	7848,	5608,	4971;...
    45,	6463,	15817,	5955,	7757;...
    50,	10893,	25843,	5782,	10574;...
    55,	17133,	38853,	5791,	14725;...
    60,	22505,	52365,	5145,	18766;...
    65,	24691,	63340,	4404,	21179;...
    70,	24317,	72177,	3890,	22445;...
    75,	21468,	77556,	3495,	22460;...
    80,	14260,	67265,	2746,	17285;...
    85,	8630,	63998,	2469,	15242};

SFMultiMort = CreateObj(h,Handle,ObjectType,BodyProps,BodyValues,...
    TableName,TableCols,TableValues,TableName2,TableCols2,TableValues2);

disp(SFMultiMort);

MultiMort = DRMultiMort;

#
# DeathRate
#

disp("\nDeathRate\n=========\n");

Age = 0:110;
Cause = {"CAN","CIR","ACC","OTH"};
CSR = zeros(length(Age),length(Cause));
Total = zeros(size(Age));
for i = 1:length(Age)
  Total(i) = DeathRate(h,MultiMort,Age(i));
  for j = 1:length(Cause)
    CSR(i,j) = DeathRate(h,MultiMort,Age(i),'',Cause(j));
  endfor
endfor
semilogy(Age,Total);
xlabel("Age");
ylabel("DeathRate");
ylim([0.00001,1]);
hold on;
for j = 1:length(Cause)
  semilogy(Age,CSR(:,j));
endfor
legend(["Total",Cause]);
hold off;

disp("Press any key to continue ...");
pause();

#
# DeathProb
#

disp("\nDeathProb\n=========\n")
AgeInterval = 5;
for i = 1:length(Age)
  Total(i) = DeathProb(h,MultiMort,Age(i),AgeInterval);
  for j = 1:length(Cause)
    CSR(i,j) = DeathProb(h,MultiMort,Age(i),AgeInterval,Cause(j));
  endfor
endfor
semilogy(Age,Total);
xlabel("Age");
ylabel("DeathProb");
ylim([0.00001,1]);
hold on;
for j = 1:length(Cause)
  semilogy(Age,CSR(:,j));
endfor
legend(["Total",Cause]);
hold off;

disp("Press any key to continue ...");
pause();

#
# Deaths
#

disp("\nDeaths\n======\n");
AgeInterval = 5;
for i = 1:length(Age)
  Total(i) = Deaths(h,MultiMort,Age(i),AgeInterval);
  for j = 1:length(Cause)
    CSR(i,j) = Deaths(h,MultiMort,Age(i),AgeInterval,Cause(j));
  endfor
endfor
plot(Age,Total);
xlabel("Age");
ylabel("Deaths");
hold on;
for j = 1:length(Cause)
  plot(Age,CSR(:,j));
endfor
legend(["Total",Cause]);
hold off;

disp("Press any key to continue ...");
pause();

#
# SurvFrac
#

disp("\nSurvFrac\n========\n");
for i = 1:length(Age)
  Total(i) = SurvFrac(h,MultiMort,Age(i));
  for j = 1:length(Cause)
    CSR(i,j) = SurvFrac(h,MultiMort,Age(i),Cause(j));
  endfor
endfor
plot(Age,Total);
xlabel("Age");
ylabel("SurvFrac");
hold on;
for j = 1:length(Cause)
  plot(Age,CSR(:,j));
endfor
legend(["Total",Cause]);
hold off;

disp("Press any key to continue ...");
pause();

#
# DeathDist
#

disp("\nDeathDist\n=========\n")
for i = 1:length(Age)
  Total(i) = DeathDist(h,MultiMort,Age(i));
  for j = 1:length(Cause)
    CSR(i,j) = DeathDist(h,MultiMort,Age(i),Cause(j));
  endfor
endfor
plot(Age,Total);
xlabel("Age");
ylabel("DeathDist");
hold on;
for j = 1:length(Cause)
  plot(Age,CSR(:,j));
endfor
legend(["Total",Cause]);
hold off;

disp("Press any key to continue ...");
pause();

#
# DyingProb
#

disp("\nDyingProb\n==========\n")
for i = 1:length(Age)
  for j = 1:length(Cause)
    CSR(i,j) = DyingProb(h,MultiMort,Cause(j),Age(i));
  endfor
endfor
plot(Age,CSR(:,1));
xlabel("Age");
ylabel("DyingProb");
ylim([0.0,0.8]);
hold on;
for j = 2:length(Cause)
  plot(Age,CSR(:,j));
endfor
legend(Cause);
hold off;

disp("Press any key to continue ...");
pause();

#
# SDSurvFrac
#

disp("\nSDSurvFrac\n==========\n")
for i = 1:length(Age)
  for j = 1:length(Cause)
    CSR(i,j) = SDSurvFrac(h,MultiMort,Cause(j),Age(i));
  endfor
endfor
plot(Age,CSR(:,1));
xlabel("Age");
ylabel("SDSurvFrac");
ylim([0.0,1.0]);
hold on;
for j = 2:length(Cause)
  plot(Age,CSR(:,j));
endfor
legend(Cause);
hold off;

disp("Press any key to continue ...");
pause();


#
# SDYearsLived
#

disp("\nSDYearsLived\n============\n");
for i = 1:length(Age)
  for j = 1:length(Cause)
    CSR(i,j) = SDYearsLived(h,MultiMort,Cause(j),Age(i));
  endfor
endfor
plot(Age,CSR(:,1));
xlabel("Age");
ylabel("SDYearsLived");
ylim([0.0,1.0]);
hold on;
for j = 2:length(Cause)
  plot(Age,CSR(:,j));
endfor
legend(Cause);
hold off;

disp("Press any key to continue ...");
pause();

#
# SDYearsLivedAfter
#

disp("\nSDYearsLivedAfter\n=================\n")
for i = 1:length(Age)
  for j = 1:length(Cause)
    CSR(i,j) = SDYearsLivedAfter(h,MultiMort,Cause(j),Age(i));
  endfor
endfor
plot(Age,CSR(:,1));
xlabel("Age");
ylabel("SDYearsLivedAfter");
ylim([0,160]);
hold on;
for j = 2:length(Cause)
  plot(Age,CSR(:,j));
endfor
legend(Cause);
hold off;

disp("Press any key to continue ...");
pause();

#
# CreateScenarioMort
#

disp("\nCreateScenarioMort\n==================\n")
Handle = "NoCAN";
ObjectType = "RESULTS";
BodyProps = {"Scenario","Cause"};
BodyValues = {"MULTIDEC","~CAN"}';

NoCANSc = CreateObj(h,Handle,ObjectType,BodyProps,BodyValues);

NewMortHandle = "NoCANMort";
MortHandle = MultiMort;
ScenarioHandle = NoCANSc;
NoCANMort = CreateScenarioMort(h,NewMortHandle,MortHandle,ScenarioHandle);
disp(NoCANMort);

disp(["LifeExp=",num2str(LifeExp(h,NoCANMort))]);
