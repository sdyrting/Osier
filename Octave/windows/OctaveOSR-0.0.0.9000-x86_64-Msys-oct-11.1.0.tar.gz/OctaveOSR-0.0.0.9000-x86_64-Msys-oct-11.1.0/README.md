
<!-- README.md is generated from README.Rmd. Please edit that file -->

# OctaveOSR

The goal of OctaveOSR is to provide an Octave interface to the Osier
library of demographic functions.

## Installation

You can install OctaveOSR from its package file:

``` octave
pkg install OctaveOSR_0.0.0.9000.tar.gz
```

## Example

Create an object using population, fertility, mortality, or migration
data.

``` octave
pkg load octaveosr
pkg load dataframe
warning off;

h=osr();

#
# Create a fertility object
#

asfr=osrd.load_dataset("aus_f_asfr_2011");

fert_name="Published";
CreateObj(h,fert_name,'FERTILITY',...
              {'Population','Date','BuildMethod'},...
              {'AUS-P/AUS-F',20110630,'CONSTANT_FERT'}',...
              'FertilityRates',...
              cellstr(asfr.colnames),...
              asfr{})
#> ans = Published:0
```

Objects can be copied or modified.

``` octave
pkg load octaveosr
pkg load dataframe
warning off;

h=osr();
asfr=osrd.load_dataset("aus_f_asfr_2011");
fert_name="Published";
CreateObj(h,fert_name,'FERTILITY',...
              {'Population','Date','BuildMethod'},...
              {'AUS-P/AUS-F',20110630,'CONSTANT_FERT'}',...
              'FertilityRates',...
              cellstr(asfr.colnames),...
              asfr{});

#
# Copy an object
#

xfert_name = 'Expanded';
CloneObj(h,xfert_name,fert_name,'FERTILITY')

#
# Modify an object
#

ModifyObj(h,'',xfert_name,'FERTILITY','','BuildMethod','','HFC:70000')
#> ans = Expanded:0
#> ans = Expanded:1
```

There are functions for calculating demographic rates and measures.

``` octave
pkg load octaveosr
pkg load dataframe
warning off;

h=osr();
asfr=osrd.load_dataset("aus_f_asfr_2011");
fert_name="Published";
CreateObj(h,fert_name,'FERTILITY',...
              {'Population','Date','BuildMethod'},...
              {'AUS-P/AUS-F',20110630,'CONSTANT_FERT'}',...
              'FertilityRates',...
              cellstr(asfr.colnames),...
              asfr{});
xfert_name = 'Expanded';
ModifyObj(h,xfert_name,fert_name,'FERTILITY','','BuildMethod','','HFC:70000');

#
# Calculate measures
#


# Age-specific fertility rate
Data={fert_name,xfert_name};
Age=0:60;
ASFR=zeros(size(Age));
hold on;
for i=1:length(Data)
  for j=1:length(Age)
    ASFR(j)=FertRate(h,Data(i),Age(j));
  endfor
  plot(Age,ASFR);
endfor
xlabel('Age');
ylabel('ASFR');
legend(Data);
hold off;
print('doc/figures/README-asfr_plot.png')

# Total fertility rate
TotalFertRate(h,xfert_name)

# Mean age at childbearing
MeanAgeChild(h,xfert_name)
#> ans = 1.9169
#> ans = 30.543
```

![](doc/figures/README-asfr_plot.png)

Objects persist until they are explicitly deleted.

``` octave
pkg load octaveosr
pkg load dataframe
warning off;

h=osr();
asfr=osrd.load_dataset("aus_f_asfr_2011");
fert_name="Published";
CreateObj(h,fert_name,'FERTILITY',...
              {'Population','Date','BuildMethod'},...
              {'AUS-P/AUS-F',20110630,'CONSTANT_FERT'}',...
              'FertilityRates',...
              cellstr(asfr.colnames),...
              asfr{});
xfert_name = 'Expanded';
ModifyObj(h,xfert_name,fert_name,'FERTILITY','','BuildMethod','','HFC:70000');

# Check an object exists
GetObj(h,xfert_name,'FERTILITY')

# Delete all objects
DeleteObjs(h,'',{''})

# Check object has been deleted
GetObj(h,xfert_name,'FERTILITY')
#> ans = Expanded:0
#> ans = Deleted 2 objects.
#> ans = Object Expanded of type FERTILITY does not exist.
```
